<?php
function validateUser($user){
	
	//global $conn;   
    $errors=array();
	
	if(empty($user['username'])){
		array_push($errors,'username is required');
	}
	
	if(empty($user['email'])){
		array_push($errors,'Email is required');
	}
	
	if(empty($user['password'])){
		array_push($errors,'Password is required');
	}
	
	if($user['passwordConf'] !== $user['password']){
		array_push($errors,'Password does not match !');
    }
	
	$existingUser=selectOne('users',['email'=>$user['email']]);
	if($existingUser){
		if(isset($post['update-user']) && $existingUser['id'] != $user['id']){
			array_push($errors,'Email Already Exists');
		}
		
		if(isset($post['create-admin'])){
			array_push($errors,'Email  Already Exists');
		}
	}
    return $errors;
}

function validateLogin($user){
	
	//global $conn;   
    $errors=array();
	
	if(empty($user['username'])){
		array_push($errors,'username is required');
	}
	
	if(empty($user['password'])){
		array_push($errors,'Password is required');
	}
	
    return $errors;
}
