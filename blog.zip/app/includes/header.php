	 <div id="header" class="clear">
    	<div id="header-content">
        				<img src="../../nielit/images/for_interface/interface.png" style="border:2px;height:auto;max-width:100%;" /> 
        </div>
    </div>
   <header class="clearfix">
    <div class="logo">
      <a href="<?php echo BASE_URL . '/index.php' ?>">
        <h1 class="logo-text"><span>E-Waste </span> Training</h1>
      </a>
    </div>
    <div class="fa fa-reorder menu-toggle"></div>
    <nav>
      <ul>
        <li><a href="<?php echo BASE_URL . '/index.php' ?>">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="<?php echo BASE_URL . '/nielit/dashboard.php' ?>">Dashboard</a></li>
        
		<?php if(isset($_SESSION['id'])):?>
        <li>
          <a href="#">
              <div class="fa fa-user"></div>
              <?php echo $_SESSION['username'];?>
              <div class="fa fa-chevron-down" style="font-size: .4em;"></div>         
          </a>
          <ul class="dropdown">
          <?php  if($_SESSION['admin']):?>
            <li><a href="<?php echo BASE_URL . '/admin/dashboard.php'?>">Dashboard</a></li>
          <?php endif; ?>
            <li><a href= "<?php echo BASE_URL . '/logout.php'?>" class="logout">logout</a></li>
			
          </ul>
        </li>
		<?php else: ?>
			<li><a href="<?php echo BASE_URL . '/register.php'?>"> Sign Up</a></li>
			<li><a href="<?php echo BASE_URL . '/login.php'?>"> Login</a></li>
    <?php endif; ?>
      </ul>
    </nav>
  </header>