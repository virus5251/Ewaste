
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CMS Login | NIELIT MDoNER Project</title>
<link rel="shortcut icon" href="/images/for_interface/nielit-shortcut-icon.png" media="all" />
<link rel="stylesheet" href="../styles/cms/cms_template.css" media="all" />
<link rel="stylesheet" href="../styles/cms/login.css" media="all" />

<script type="text/javascript" src="scripts/jquery-1.9.0.js"></script>
<script type="text/javascript" src="scripts/value-trimmer.js"></script>
<script type="text/javascript" src="scripts/common.js"></script>
<script type="text/javascript" src="scripts/cms/login_php.js"></script>
</head>

<body>
	<!-- Menu Section -->
	<div id="top-section">
		<div id="top-content">
        	<!-- Menu Section -->
			<ul id="menu-bar" class="float-left">
	
       
    <li id="cms_home" class="menu-item float-left"><a href="../index.php">Home</a></li>
    
  
</ul>
			<!-- End of Menu section -->
            </div>
	</div>
	<!-- End of Menu section -->
	
	<!-- Header Section -->
    <div id="header" class="clear">
    	<div id="header-content">
        				<img src="../images/for_interface/logoheader.jpg" style="border:2px;height:auto;max-width:100%;" /> 
            <!-- Contents are provided and maintained by NIELIT Agartala Centre -->
        </div>
    </div>
    <!-- End of Header Section -->
    
	<!-- Body Section  -->
	<div id="body-section" class="clear">
    	<!-- Body Alignment Section -->
		<div id="body-alignment">
        	
            <!-- Body Content Section -->
			<div id="body-content">
            	<noscript class="disabled_javascript">
           			JavaScript is disabled in your browser.
                    Either enable JavaScript and refresh this page or use a JavaScript enabled latest browser.
				</noscript>
            
            	<div class="clear horiz-diff"></div>
				
				<!---------------------------->
                
				<div id="horiz-sec-1">
                	<h1 class="headings" align="center">Welcome to MIS of DoNER Project Course Coordinator/Assistant Coordinator Login Section</h1>
                    
                	<div align="center">
                    	<div class="clear horiz-diff"></div>
                        
                        <form name="login-form" id="login-form" action="login_check.php" method="post">
                        	<table align="center">
		                    	<tr>
        		                	<td>Username: </td>
                		            <td><input type="text" name="username" id="username" size="25" tabindex="1" /></td>
		                        </tr>
        		                <tr>
                		        	<td>Password: </td>
                        		    <td><input type="password" name="password" id="password" size="25" tabindex="2" onpaste="return false;" /></td>
        		                </tr>
								<tr>
                		        	<td class="first-td">Login  Role</td>
        		                	    <td>
                	        	        	<select name="role" id="role" class="input-select" tabindex="3">
											<option value="empty">Select Role</option>
											<!--<option value="Academic-In-Charge">Academic-In-Charge</option>-->
                                        	<option value="Course-Coordinator">Course Coordinator</option>
											<option value="Asst-Coordinator">Assistant Coordinator</option>
											
                                           
                                        </select>
                    		            </td>
        		                </tr>
                		        <tr>
		                            <td colspan="2">
        		                    	<div id="captcha-container" class="float-left" style="padding-left: 65px;">
                		                	<img id="captcha" src="captcha.php" width="108" height="25" />
                        		        </div>
		                                
        		                        <div id="reload-container" class="float-right">
                		                	<img id="reload-captcha" src="../images/for_interface/reload.png" width="10" height="15" title="Reload Captcha" />
                        		        </div>
		                            </td>
        		                </tr>
		                        <tr>
        		                	<td>
                		            	<!-- HIDDEN VALUES FOR SECURITY -->
                        		        <input type="hidden" name="js_status" id="js_status" value="0" />
		                            </td>
        		                    <td style="text-align: center;">(Type the above code)</td>
                		        </tr>
		                        <tr>
		                        	<td></td>
        		                    <td>
                		            	<input type="text" name="icaptcha" id="icaptcha" size="25" tabindex="3" />
		                            </td>
		                        </tr>
        		                <tr>
                		        	<td></td>
                        			<td style="text-align: right;">
		                            	<input type="submit" value="Login" id="submit" tabindex="4" />
        		                    </td>
                		        </tr>
							</table>
                            
                            <table align="center">
                        		<tr>
        		                	<td colspan="10" id="error_message" style="text-align: center;">
		                            			                            </td>
		                        </tr>
		                    </table>
		                </form>
					</div>
					<!-- End of Row 3, Column 2 -->
                </div>
            </div>
	        <!-- End of Body Content Section -->
        </div>
        <!-- End of Body Alignment Section -->
    </div>
    <!-- End of Body Section -->
    
    <!-- Footer Section -->
    <div id="footer" class="clear">
    	<div id="footer-content">
        	<div class="clear horiz-diff">
	&copy; National Institute of Electronics & Information Technology(NIELIT). All Rights Reserved.<br />
   
    
</div>

        </div>
    </div>
    <!-- End of Footer Section -->
</body>
</html>
