<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>E-Waste Capacity Building project sponsored by MeitY</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Monthly css -->
        <link href="assets/plugins/monthly/monthly.css" rel="stylesheet" type="text/css" />
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">

        <link href="assets/plugins/ssi-modal/ssi-modal.css" rel="stylesheet" type="text/css" />

         <link href="assets/dist/css/let-it-snow.css" rel="stylesheet" type="text/css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--  <script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
-->
 <script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="./dash-home.jsp_files/drilldown.js.download"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>

<script>

$(document).ready(function(){
                    ssi_modal.notify('info', {
                        position: 'left bottom',
                        content: 'Average Age of Candidate: 41.4'
                    })
                });


  $(function () {


    /*Highcharts.setOptions({
     colors: ['#434348','#8085e9','#90ed7d','#2b908f','#f7a35c','#f15c80','#e4d354','#7cb5ec'
]
    });*/

      $('#piecha').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'State Wise Candidates List'
        },
        
        subtitle: {
            text: 'Total Registered Candidates : <b>10000</b>',
            x: -20
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b> <br> PERC: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black' 

                    }
                }
            }
        },
        series: [{
            name: 'Candidates',
            colorByPoint: true,
            data: [{
                name: 'Arunachal Pradesh (AR) <br> COUNT : 592 ',
                y: 0.0592,
                sliced: true,
                selected: true
            }

 

, { name:'Manipur (MN) <br> COUNT : 601 ',     
  y: 0.0601  }
, { name:'Meghalaya (ML) <br> COUNT : 428 ',     
  y: 0.0428  }
 , { name:'Mizoram (MZ) <br> COUNT : 257 ',     
  y: 0.0257 
  }
  , { 
    name:'Assam (AS) <br> COUNT : 6838 ',     
  y: 0.6838  }

 , { name:'Nagaland (NL) <br> COUNT : 275 ',     
  y: 0.0275 
  }

 , { name:'Sikkim (SK) <br> COUNT : 172 ',     
  y: 0.0172 
  }

 , { name:'Tripura (TR) <br> COUNT : 837 ',     
  y: 0.0837 
  }
            
]
}],
        credits: {
    enabled: false
  }
    });
    
    





$('#piechaSmallScreen').highcharts({
         chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'State Wise Candidates List'
        },
        
        subtitle: {
            text: 'Total Registered Candidates : <b>10000</b>',
            x: -20
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b> <br> PERC: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black' 

                    }
                }
            }
        },
        series: [{
            name: 'Candidates',
            colorByPoint: true,
            data: [{
                name: 'Arunachal ',
                y: 0.0592,
                sliced: true,
                selected: true
            }

 

, { name:'Manipur <br>',     
  y: 0.0601  }
, { name:'Meghalaya <br>',     
  y: 0.0428  }
 , { name:'Mizoram <br>',     
  y: 0.0257 
  }
  , { 
    name:'Assam <br>',     
  y: 0.6838  }

 , { name:'Nagaland <br>',     
  y: 0.0275 
  }

 , { name:'Sikkim <br>',     
  y: 0.0172 
  }

 , { name:'Tripura <br>',     
  y: 0.0837 
  }
            
]
}],
        credits: {
    enabled: false
  }
    });
    
    







$('#feedback_piechart').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Feedback Chart'
        },
        
        subtitle: {
            text: 'Total Feedback : <b>8347</b>',
            x: -20
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b> <br> PERC: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black' 

                    }
                }
            }
        },
        series: [{
            name: 'Feedback',
            colorByPoint: true,
            data: [{
                name: 'Excellent  <br> COUNT : 4190 ',
                y: 0.50197675811669,
                sliced: true,
                selected: true
            }

 , { 
    name:'Very Good  <br> COUNT : 3848 ',     
  y: 0.46100395351623  }

, { name:'Average <br> COUNT : 293 ',     
  y: 0.035102432011501  }
, { name:'Poor  <br> COUNT : 11 ',     
  y: 0.0013178387444591  }

 , { name:'Very Poor <br> COUNT : 5 ',     
  y: 0.00059901761111777 
  }
 
            
]
}],
        credits: {
    enabled: false
  }
    });
    
    

Highcharts.chart('feedback_state_Areachart', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Feedback Overall Training Rating'
    },
    subtitle: {
        text: 'Total Feedback:<b>8347</b>'
    },
    xAxis: {
        categories: ['Arunachal Pradesh', 'Assam', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Sikkim', 'Tripura'],
        tickmarkPlacement: 'on',
        title: {
            enabled: false
        }
    },
    yAxis: {
        title: {
            text: 'Percent'
        }
    },
    tooltip: {
      
      headerFormat: 'State: {point.key}',
        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.1f}%</b> ({point.y:,.0f} nos.)<br/>',
        split: true
    },
    plotOptions: {
        area: {
            stacking: 'percent',
            lineColor: '#ffffff',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#ffffff'
            }
        }
    },
    series: [{
        name: 'Excellent',
        data: [230,2718,240,217,140,124,126,395]
    }, {
        name: 'Good',
        data: [215,2600,278,194,83,103,42,332]
    }, {
        name: 'Average',
        data: [17,206,20,16,3,2,3,26]
    }, {
        name: 'Poor',
        data: [1,7,0,1,0,0,0,2]
    }, {
        name: 'Very Poor',
        data: [1,1,1,0,0,0,0,2]
    }],
        credits: {
    enabled: false
  }
});




Highcharts.chart('state_barchart', {
    
    title: {
        text: 'Registered candidates'
    },
    xAxis: {
        categories: ['Arunachal Pradesh', 'Assam', 'Manipur', 'Meghalaya','Mizoram','Nagaland','Sikkim' ,'Tripura'],
        labels: {
          
            style: {
                fontSize: '16px'
            }
        }
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: 'No. of Candidates'
        }
    },

    tooltip: {
    borderRadius  : 2,
        borderWidth   : 1,
        borderColor   : '#999',
      shadow      : false,
        shared      : true,
        useHTML     : true,
      yDecimals   : 0,
            valueDecimals : 0,
            formatter: function() {
                var points='<caption>State '+this.x+'</caption>'
                +'<br>';
                $.each(this.points,function(i,point){
                    points+='<span style="color: '+point.series.color+'">'+point.series.name+': '
                    + point.y+'</span><br>'
                });
                points+='<span>Total: '
            +'<b>'+this.points[0].total+'</b>';
                return points;
            }
              
    },

    plotOptions: {
        column: {
            stacking: 'normal',
            pointPadding: 0.2,
                    borderWidth: 3,
                   /* dataLabels: {
                enabled: true,
                format: '{point.y}'
            }*/

        }
    },

    series: [{
       color: '#DC7633',
        type: 'column',
        name: 'SC',
        data: [2,432,50,1,1,0,6,158],
        stack: 'category'
    }, {
         color: '#5499C7',
        type: 'column',
        name: 'ST',
        data: [513,1225,148,421,255,274,55,209],
        stack: 'category'
    }, {
        color: '#808B96',
        type: 'column',
        name: 'OBC',
        data: [8,2658,109,1,0,1,88,147],
        stack: 'category'
    }, {
        color: '#48C9B0',
        type: 'column',
        name: 'GEN',
        data: [69,2523,294,5,1,0,23,323],
        stack: 'category'
    },{
        color: '#F5B041',
        type: 'spline',
        name: 'Male',
        data: [282,5120,348,264,157,155,32,631]
    }, {
        color: '#850707',
        type: 'spline',
        name: 'Female',
        data: [310,1718,253,164,100,120,140,206]
    }

    ],
        credits: {
    enabled: false
  }
});








Highcharts.chart('month_barchart', {
    
    chart: {
        type: 'column'
    },

    title: {
        text: 'Trained candidates'
    },

    xAxis: {
        categories: ['January', 'February', 'March','April','May','June','July','August','September','October','November','December']
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: 'Trained candidates '
        }
    },

   tooltip: {
    borderRadius  : 2,
        borderWidth   : 1,
        borderColor   : '#999',
      shadow      : false,
        shared      : true,
        useHTML     : true,
      yDecimals   : 0,
            valueDecimals : 0,
            formatter: function() {
                var points='<caption>Month: '+this.x+'</caption>'
                +'<br>';
                $.each(this.points,function(i,point){
                    points+='<span style="color: '+point.series.color+'">'+point.series.name+': '
                    + point.y+'</span><br>'
                });
                //points+='<span>Total: '+'<b>'+this.points[0].total+'</b>';
                return points;
            }
              
    },

     plotOptions: {
        column: {
            stacking: 'normal',
            pointPadding: 0.2,
                    borderWidth: 3,
                    dataLabels: {
                enabled: true,
                format: '{point.y}'
            }

        }
    },


    series: [{
       color: '#DC7633',
        name: 'SC',
        data: [10,44,26,34,70,37,43,53,43,24,111,143],
        stack: 'Category'
    }, {
         color: '#5499C7',
        name: 'ST',
        data: [22,304,212,201,321,250,226,321,260,256,294,394],
        stack: 'Category'
    }, {
        color: '#808B96',
        name: 'OBC',
        data: [11,226,171,144,281,165,184,364,217,230,456,535],
        stack: 'Category'
    }, {
        color: '#48C9B0',
        name: 'GEN',
        data: [12,168,175,133,343,207,218,394,267,255,509,495],
        stack: 'Category'
    },{
       color: '#ffb267',
        name: 'Male',
        data: [46,476,370,339,710,453,493,876,549,556,1007,1040],
        stack: 'Male'
    }, {
        color: '#850707',
        name: 'Female',
        data: [9,266,214,173,305,206,178,256,238,209,363,527],
        stack: 'Female'
    }, {
        color: '#850707',
        type: 'spline',
        name: 'Total candidate',
        data: [55,742,
        584,512,
        1015, 659,
        671, 1132,787,765,1370,1567

]
    }


    ],
        credits: {
    enabled: false
  }
});



/**
 * Create a constructor for sparklines that takes some sensible defaults and merges in the individual
 * chart options. This function is also available from the jQuery plugin as $(element).highcharts('SparkLine').
 */
Highcharts.SparkLine = function (a, b, c) {
    var hasRenderToArg = typeof a === 'string' || a.nodeName,
        options = arguments[hasRenderToArg ? 1 : 0],
        defaultOptions = {
            chart: {
                renderTo: (options.chart && options.chart.renderTo) || this,
                backgroundColor: null,
                borderWidth: 0,
                type: 'area',
                margin: [2, 0, 2, 0],
                width: 120,
                height: 20,
                style: {
                    overflow: 'visible'
                },

                // small optimalization, saves 1-2 ms each sparkline
                skipClone: true
            },
            title: {
                text: ''
            },
            credits: {
                enabled: false
            },
            xAxis: {
                labels: {
                    enabled: false
                },
                title: {
                    text: null
                },
                startOnTick: false,
                endOnTick: false,
                tickPositions: []
            },
            yAxis: {
                endOnTick: false,
                startOnTick: false,
                labels: {
                    enabled: false
                },
                title: {
                    text: null
                },
                tickPositions: [0]
            },
            exporting: {
                        enabled: false
                    },
            legend: {
                enabled: false
            },
            tooltip: {
                backgroundColor: null,
                borderWidth: 0,
                shadow: false,
                useHTML: true,
                hideDelay: 0,
                shared: true,
                padding: 0,
                positioner: function (w, h, point) {
                    return { x: point.plotX - w / 2, y: point.plotY - h };
                }
            },
            plotOptions: {
                series: {
                    animation: false,
                    lineWidth: 1,
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                    marker: {
                        radius: 1,
                        states: {
                            hover: {
                                radius: 2
                            }
                        }
                    },
                    fillOpacity: 0.25
                },
                column: {
                    negativeColor: '#910000',
                    borderColor: 'silver'
                }
            }
        };

    options = Highcharts.merge(defaultOptions, options);

    return hasRenderToArg ?
        new Highcharts.Chart(a, options, c) :
        new Highcharts.Chart(options, b);
};

var start = +new Date(),
    $tds = $('td[data-sparkline]'),
    fullLen = $tds.length,
    n = 0;

// Creating 153 sparkline charts is quite fast in modern browsers, but IE8 and mobile
// can take some seconds, so we split the input into chunks and apply them in timeouts
// in order avoid locking up the browser process and allow interaction.
function doChunk() {
    var time = +new Date(),
        i,
        len = $tds.length,
        $td,
        stringdata,
        arr,
        data,
        chart;

    for (i = 0; i < len; i += 1) {
        $td = $($tds[i]);
        stringdata = $td.data('sparkline');
        arr = stringdata.split('; ');
        data = $.map(arr[0].split(', '), parseFloat);
        chart = {};

        if (arr[1]) {
            chart.type = arr[1];
        }
        $td.highcharts('SparkLine', {
            series: [{
                data: data,
                pointStart: 1
            }],
            tooltip: {
                headerFormat: '<span style="font-size: 10px">' +  ' Month: {point.x}:</span>',
                pointFormat: '<b>{point.y}</b> nos.'
            },
            chart: chart
        });

        n += 1;

        // If the process takes too much time, run a timeout to allow interaction with the browser
        if (new Date() - time > 500) {
            $tds.splice(0, i + 1);
            setTimeout(doChunk, 0);
            break;
        }

        // Print a feedback on the performance
        if (n === fullLen) {
            $('#result').html('Generated ' + fullLen + ' sparklines in ' + (new Date() - start) + ' ms');
        }
    }
}
doChunk();



   }); 
   
</script>
    </head>
    <body>    
		<div id="wrapper">
            <!--navbar top-->
            <nav class="navbar navbar-inverse navbar-fixed-top" style="min-height:75px">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="120" height="80">
                </a>                 
                <ul>
				<li style="color:#000033;" >
    				   		<img src="assets/dist/img/nielit_hindi.png" alt="MDoner" height="25px" width="300px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">National Institute of Electronics & Information Technology, Gangtok
							<br>
								MeitY, Government of India</span>
				</li>
 				<li class="hidden-xs" id="DILogo">
                		<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo"  height="82px" style="" />
                </li>
                </ul>
                <div class="navbar-custom-menu hidden-xs">    
                   <ul class="navbar navbar-right">
                       <li style="color:#000033;" >
    				   		<img src="assets/dist/img/e-waste-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">E-Waste Capacity Building project sponsored by MeitY, Government of India</span>
                       </li>
					   <li style="padding-top: 3px">
					   <img src="emblem.png" width="45" height="75"/>
					   </li>
				   </ul>
                </div>
            </nav>
            <!-- Sidebar -->
           <!-- <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-image: url(assets/dist/img/fabric.png);">-->
           <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-color:#000033">
             <div class="navbar-default sidebar" role="navigation">
               <div class="sidebar-nav navbar-collapse">
                 <ul class="nav" id="side-menu">
                   <li class="active-link"><a href="../index.php"><i class="material-icons">dashboard</i>Home</a></li>
                   <li><a href="about.php"><i class="material-icons">location_city</i>About the Project</a></li>
                   <li><a href="state_org_report.php"><i class="material-icons">location_city</i>Organization Details</a></li>
                   <li><a href="drilldown_report.php"><i class="material-icons">people</i>Candidate Details</a></li>
                   <li><a href="state_tc_report.php"><i class="material-icons">place</i>Training Venue</a></li>
                   <li><a href="state_batch_report.php"><i class="material-icons">dashboard</i>Batch Details</a></li>
                   <li><a href="feedback_consol_report.php"><i class="material-icons">dashboard</i>Feedback Report</a></li>
                   <li><a href="batch_image_gallery.php"><i class="material-icons">image</i>Image Gallery</a></li>
                   <li><a href="feedback-login.php"><i class="material-icons">lock</i>Feedback Login</a></li>
                   <li><a href="administration_login.php"><i class="material-icons">lock</i>Admin Login</a></li>
                   <li class="side-last"></li>
                 </ul>
                 <!-- ./sidebar-nav -->
               </div>
               <!-- ./sidebar -->
             </div>
             <!-- ./sidebar-nav -->
           </div>
           <script>
			   var screen_width = screen.width;
			   var DI_logo_padding =  0;
	
			   if(screen_width>=1300){
				 DI_logo_padding  = (screen_width - 1300)/2;
			   }
			   DI_logo_padding = "2px 0 0 "+DI_logo_padding+"px";
			   document.getElementById("DILogo").style.padding = DI_logo_padding ;
        	</script>
            <!-- ./sidebar-wrapper -->
            <!-- Page content -->
 			<div id="page-content-wrapper"><!--changing purpose-->
				<div class="page-content">
					<div class="container-fluid">
                		<div class="row">
						<div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 align="center" style="font-style:italic;"><strong>E-Waste Capacity Building project sponsored by MeitY</strong></h1>
									</div>
								</div>
							</div>      
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="panel cardbox bg-primary " style="background-image: url(assets/dist/img/fabric.png) ">
                                    <div class="panel-body card-item panel-refresh">
                                        <a class="refresh" href="#">
                                            <span class="fa fa-refresh"></span>
                                        </a> 
                                        <div class="refresh-container"><i class="refresh-spinner fa fa-spinner fa-spin fa-5x"></i></div>
                                        <div class="timer" data-to="10178" data-speed="1500">0</div>
                                        <i class="pin"></i>
                                        <div class="cardbox-icon">
                                            <i class="material-icons">local_library</i>
                                        </div>
                                        <div class="card-details">
                                            <h4><a href="state_batch_report.php" style="color:#fff">Nominated Candidates</a></h4>
                                            <span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
							
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="panel cardbox bg-success" style="background-color:#943d3d;background-image: url(assets/dist/img/fabric.png) ">
                                    <div class="panel-body card-item panel-refresh">
                                        <a class="refresh" href="#">
                                            <span class="fa fa-refresh"></span>
                                        </a> 
                                        <div class="refresh-container"><i class="refresh-spinner fa fa-spinner fa-spin fa-5x"></i></div>
                                        <div class="timer" data-to="10000" data-speed="1500">0</div>
                                         <i class="pin"></i>
                                        <div class="cardbox-icon">
                                            <i class="material-icons">school</i>
                                        </div>
                                        <div class="card-details">
                                            <h4>Registered Candidates</h4>
                                            <span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="panel cardbox bg-warning" style="background-image: url(assets/dist/img/fabric.png) ;background-color: #a25e25">
                                    <div class="panel-body card-item panel-refresh">
                                        <a class="refresh2" href="#">
                                            <span class="fa fa-refresh"></span>
                                        </a> 
                                        <div class="refresh-container"><i class="refresh-spinner fa fa-spinner fa-spin fa-5x"></i></div>
                                        <div class="timer" data-to="10000" data-speed="1500">0</div>
                                         <i class="pin"></i>
                                        <div class="cardbox-icon">
                                            <i class="material-icons">visibility</i>
                                        </div>
                                        <div class="card-details">
                                            <h4><a href="state_batch_report.php" style="color:#fff">Trained Candidates</a></h4>
                                            <span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
							
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="panel cardbox bg-dark" >
                                    <div class="panel-body card-item panel-refresh">
                                        <a class="refresh" href="#">
                                            <span class="fa fa-refresh"></span>
                                        </a> 
                                        <div class="refresh-container"><i class="refresh-spinner fa fa-spinner fa-spin fa-5x"></i></div>
                                        <div class="timer" data-to="616" data-speed="1500">0</div>
                                         <i class="pin"></i>
                                        <div class="cardbox-icon">
                                            <i class="material-icons">location_city</i>
                                        </div>
                                        <div class="card-details">
                                            <h4><a href="state_org_report.php" style="color:#fff">No. of  Organizations</a></h4>
                                            <span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-bar-chart fa-lg"></i>
                                        <h2>Candidate StateWise GenderWise
                                        <!-- <a style="float:right" href="PHPExcel/Examples/state_category_Gender_report.php">
      <img src="assets/dist/img/excel-download-icon.png" title="State Category Gender Wise Report" alt="Excel" height="26" width="26"></a>-->
 	 									</h2>
                                    </div>
                                    <div class="card-content"><!--FOR DB PURPOSE-->
                                        <div id="month_barchart"></div>
                                           <table id="dataTableExample1" class="table table-bordered table-striped table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>Month</th>
                                                        <th>January</th>
                                                        <th>February</th>
                                                        <th>March</th>
                                                        <th>April</th>
                                                        <th>May</th>
                                                        <th>June</th>
                                                        <th>July</th>
														<th>August</th>
														<th>September</th>
														<th>October</th>
														<th>November</th>
														<th>December</th>
														<th>Total Trained</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><b>Trained</b></td>
                                                        <td>55</td>
                                                        <td>742</td>
                                                        <td>584</td>
                                                        <td>512</td>
                                                        <td>1015</td>
                                                        <td>659</td>
														<td>671</td>
														<td>1132</td>
														<td>787</td>
														<td>765</td>
														<td>1370</td>
														<td>1567</td>
														<td>10000</td>                                                        
     												</tr>
                                               </tbody>
                                      	</table>  
                                    </div>
                                </div>
                          	</div>
							
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-pie-chart fa-lg"></i>
                                        <h2>Candidate StateWise Details</h2>
                                    </div>
                                    <div class="card-content">
                                        <div id="piecha" class="hidden-xs hidden-sm">
                                	</div>
                                	<div id="piechaSmallScreen" class="hidden-lg hidden-md">
                                	</div>
 									<table id="dataTableExample1" class="table table-bordered table-striped table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>State</th><th>AR</th>
                                                        <th>AS</th><th>MN</th>
                                                        <th>ML</th><th>MZ</th>
                                                        <th>NL</th><th>SK</th>
                                                        <th>TR</th></tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>Count</td>
                                                        <td>592</td>
                                                        <td>6838</td>
                                                        <td>601</td>
                                                        <td>428</td>
                                                        <td>257</td>
                                                        <td>275</td>
                                                        <td>172</td>
                                                        <td>837</td>      
                                                  </tr>
                                               </tbody>
                                      </table>   
                                    </div>
                                </div>
                            </div>

  							<div  class=" col-lg-6 col-md-6 col-sm-12 col-xs-12" >
                                    <div class="card">
                                    	<div class="card-header">
                                        	<i class="fa fa-bar-chart fa-lg"></i>
                                        		<h2>Feedback StateWise</h2>
                                    	</div>
                                    	<div class="card-content" >
	                                    <div id="feedback_state_Areachart">                            
                                		</div>
                                        <table id="dataTableExample1" class="table table-bordered table-striped table-hover ">
                                                	<thead>
                                                            <tr>
																<th>Excellent</th> 
                                                              	<th>Good</th>
                                                             	<th>Average</th>
                                                             	<th>Poor</th>
                                                             	<th>Very Poor</th>
															</tr>
													</thead>
													<tbody>
                                                             <tr>
																 <td>4190 / 50.1 % </td>
																 <td>3847 / 46.0 % </td>
																 <td>293 / 3.51 %</td>
																 <td>11 / 0.13 %</td>
																 <td>5 / 0.05 %</td>
															</tr>
													</tbody>
										  </table>
                                   	  </div>
                                    </div>
                          	</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="display:none">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-bar-chart fa-lg"></i>
                                        <h2>Candidate StateWise GenderWise <a style="float:right" href="PHPExcel/Examples/state_category_Gender_report.php">
      									<img src="assets/dist/img/excel-download-icon.png" title="State Category Gender Wise Report" alt="Excel" height="26" width="26"></a></h2>
                                    </div>
                                    <div class="card-content">
                                        <div id="state_barchart"></div>
                                           <table id="dataTableExample1" class="table table-bordered table-striped table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>Male</th>
                                                        <th>Female</th>
                                                        <th>SC</th>
                                                        <th>ST</th>
                                                        <th>OBC</th>
                                                        <th>GEN</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>6989</td>
                                                        <td>3011</td>
                                                        <td> 650</td>
                                                        <td> 3100</td>
                                                        <td> 3012</td>
                                                        <td> 3238</td>      
                                                  </tr>
                                               </tbody>
                                      </table>   
                                    </div>
                                </div>
                          	</div>
  							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="border:none">
    							<div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Targets for 2018 calender year</h2>
                                    </div>
                                    <div class="card-content" >
                                 	<br>
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>State</th> 
														<th style="max-width: 100px;">Training Venue</th>
														<th>Avg Age<sup>*</sup></th>
                                                        <th>Target</th> 
														<th>Registered</th>
														<th>Trained</th>
                                                        <th>Perc</th> 
														<th class="hidden-xs hidden-sm">Progress</th>
														<th>Month Wise Progress</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
														<td>Arunachal Pradesh</td>
														<td>4</td>
                                                        <td>40.1</td>
														<td>303</td>
														<td>592 </td>
		                                                <td>592</td>
                                       					<td>195.%</td>
                   										<td class="hidden-xs hidden-sm">
														<div class="progress">
                                       						<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="25" aria-valuemin="0" 		                                                            	aria-valuemax="100" style="width:195.3795379538%">
                                       						</div> 
									   					</div>
                                      					</td>
                                      					<td data-sparkline=" 7 , 72 , 131 , 0 , 36 , 56 , 52 , 98 , 44 , 25 , 32 , 39"/>
                                                  	</tr>
                                                    <tr>
                                                        <td>Assam</td>
                                                        <td>13</td>
                                                        <td>45.7</td>
                                                        <td>6837</td>
                                                        <td>6838                                                          
                                                        <td>6838</td> 
                                       					<td>100.%</td>
                                            			<td class="hidden-xs hidden-sm">
														<div class="progress">
                                            				<div class="progress-bar progress-bar-striped active " role="progressbar" aria-valuenow="40" aria-valuemin="0" 			 																aria-valuemax="100"style="width:100.01462629808%">
                                            				</div>
														</div>
														</td>
                                            			<td data-sparkline="0 , 489 , 346 , 273 , 653 , 329 , 368 , 881 , 514 , 616 , 1142 , 1227 "/>
                                                  </tr>
                 									  <tr>
                                                        	<td>Manipur</td>
                                                        	<td>9</td>
                                                        	<td>43.3</td>
                                                        	<td>597</td>
                                                        	<td>601 </td>
                                                        	<td>601</td>
                                                        	<td>100.%</td>
                                                            <td class="hidden-xs hidden-sm">
															<div class="progress">
                                            					<div class="progress-bar progress-bar-striped active " role="progressbar" aria-valuenow="55" aria-valuemin="0"      																aria-valuemax="100" style="width:100.67001675042%">
                                            					</div>
															</div>
															</td>
                                            				<td data-sparkline="34 , 96 , 31 , 31 , 75 , 86 , 83 , 47 , 29 , 28 , 9 , 10 "/>
                                                  </tr>
                                                        <tr>
															<td>Meghalaya</td>
															<td>4</td>
															<td>40.0</td>
															<td>650</td>
															<td>428 </td>
															<td>428</td>
															<td>65.8%</td>
                                                            <td class="hidden-xs hidden-sm">
															<div class="progress">
                                            					<div class="progress-bar progress-bar-striped active  " role="progressbar" aria-valuenow="75" aria-valuemin="0"     																aria-valuemax="100" style="width:65.846153846154%">
                                                              </div>
														    </div>
                                            				</td>
                                                            <td data-sparkline="6 , 0 , 0 , 14 , 18 , 65 , 61 , 76 , 67 , 60 , 21 , 40 "/>
                                                  </tr>
                                                            <tr>
																<td>Mizoram</td>
																<td>2</td>
																<td>42.4</td>
																<td>239</td>
																<td>257 </td>
																<td>257</td>
																<td>107.%</td>
																<td class="hidden-xs hidden-sm"> 
																<div class="progress">
                                            						<div class="progress-bar progress-bar-striped active  " role="progressbar" aria-valuenow="90" aria-valuemin="0" 																		aria-valuemax="100" style="width:107.53138075314%">
                                            						</div> 
																</div>
                                        						</td>
                                            					<td data-sparkline="21 , 0 , 17 , 40 , 89 , 50 , 32 , 30 , 82 , 0 , 166 , 241"/>
                                                            </tr>
                                                            <tr>
																<td><b>Total</b></td>
																<td><b>54</b></td>
																<td><strong>41.4</strong></td>
																<td><b>10000</b></td>
																<td><b>10000</b> </td>
																<td><b>10000</b></td>
																<td><b>100%</b></td>
																<td class="hidden-xs hidden-sm">
																<div class="progress">
                                            						<div class="progress-bar progress-bar-striped active  " role="progressbar" aria-valuenow="90" aria-valuemin="0" 																		aria-valuemax="100" style="width:100%">   
                                            						</div>
																</div>
                                            					</td>
                                            					<td ></td>
                                                  </tr>              
                                              </tbody>
                                            </table>
                                      <br>
                                      * Average Age of Registered Participiants                      
              				  </div>
           				   </div>
                       </div>
				</div>
                                      
                            <!-- ./Messages -->
                  </div>
                        <!-- ./row -->
          </div><!-- ./cotainer -->
          </div> <!--changing purpose-->
                <!-- ./page-content -->
    </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- materialize  -->
        <script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
        <!-- metismenu-master -->
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- SlimScroll -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <script src="assets/plugins/sparkline/sparkline.min.js" type="text/javascript"></script>
        <!-- Counter js -->
        <script src="assets/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
         <script src="assets/plugins/ssi-modal/ssi-modal.min.js" type="text/javascript"></script>
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
       
     <script>
                                    

/**
 * Get the current time
 */
function getNow() {
    var now = new Date();

    return {
        hours: now.getHours() + now.getMinutes() / 60,
        minutes: now.getMinutes() * 12 / 60 + now.getSeconds() * 12 / 3600,
        seconds: now.getSeconds() * 12 / 60
    };
}


                                </script>



<style>
    .highcharts-data-labels tspan{
        font-size: 10px !important;
    }
    #piechaSmallScreen .highcharts-text-outline{
      font-size:10px !important;

    }
    #clock .highcharts-background{
      background:#131D27;
      background-image: url(assets/dist/img/fabric.png);
    }
    .card{
          box-shadow: -1px -1px 3px rgba(0,0,0,0.2), 12px 12px 20px rgba(0,0,0,0.6), inset 2px 2px 0 rgba(255, 255, 255, 0.1);
    }
</style>

    </body>

</html>
