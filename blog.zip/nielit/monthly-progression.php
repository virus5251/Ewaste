

<!DOCTYPE html>
<html lang="en">


    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Capacity Building in IT and Digital literacy</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap-theme.min.css">
<!--<link rel="stylesheet" href="https://mdbootstrap.com/previews/docs/latest/css/mdb.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Monthly css -->
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">

        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/dist/css/main-design.css" rel="stylesheet">
        <link href="assets/news/css/site.css" rel="stylesheet" type="text/css" />
        <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


 
    </head>

    <body>

         <div id="wrapper" style="padding-left:0px;">
            <!--navbar top-->
           

 <nav class="navbar navbar-inverse navbar-fixed-top" style="">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="200" height="80">
                </a>
                
             
                <ul>
                	<li style="padding:10px 10px 0 10px;box-shadow: inset 1px 0 0 0 #ddd;color: #282d40;font-size:12px;" class="hidden-xs">
                	
                	राष्ट्रीय इलेक्ट्रॉनिकी एवं सूचना प्रौद्योगिकी संस्थान
<br>
National Institute of Electronics &amp; Information Technology 
<br>
MeitY, Government of India
                
                </li>
 <li class="hidden-xs" id="DILogo" style="padding: 2px 0px 0px 30px;">
                	<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo" height="82px" style="">
                </li>
                </ul>
                
               
                <div class="navbar-custom-menu hidden-xs hidden-sm">
                    
                    <ul class="navbar navbar-right">
                       
                       
                       
<li style="color: #282d40;" >
   
    <img src="assets/dist/img/doner-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
<br>
<span style="float:right;padding-right:10px;font-size: 12px;">An initiative under Science &amp; Technology Interventions in the North Eastern Region (STINER)</span>
               
                        </li>

<li style="padding-top: 3px">
<img src="emblem.png" width="45" height="75"/></li>
                      </ul>
                </div>
            </nav>

<nav class="mainMenu navbar navbar-collapse navbar-fixed-top" style="height: 50px;margin-top:  80px;z-index: 4000;">
                <!-- Logo -->
               
                
             
               <ul class="nav navbar-nav">
      <li class="active"><a href="index.php" class=" waves-effect waves-light" style="
    font-size: 16px;
">Home</a></li>
      <li><a href="about.php" class=" waves-effect waves-light" style="
    font-size: 16px;
">About Project</a></li>
   <!--   <li><a href="#" class=" waves-effect waves-light" style="
    font-size: 16px;
">Training</a></li>
-->
<li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Training <span class="caret"></span></a>
                <ul class="dropdown-menu" style="background-color: #304065;">
                  <li><a href="about.php#course">Training Curriculum</a></li>
                  <li><a href="#">State Targets</a></li>
                  <!--<li role="separator" class="divider"></li>
                  <li class="dropdown-header">Nav header</li>
                  <li><a href="#">Separated link</a></li>
                  <li><a href="#">One more separated link</a></li>-->
                </ul>
              </li>
              <li><a href="dashboard.php" class=" waves-effect waves-light" style="
    font-size: 16px;
">Dashboard</a></li>
<li><a href="monthly-progression.php" class=" waves-effect waves-light" style="
    font-size: 16px;
">Monthly Progression Report</a></li>
    
      <li>
               
                <div class="navbar-custom-menu hidden-xs">
                    
                   <ul class="navbar navbar-right">
                       
               </ul>
                </div>
            </li></ul></nav>

            
<blockquote class="block-summery hidden-xs hidden-sm" style="z-index:2000;
    color: #000;text-align:center;margin:122px -1px 0px -20px;opacity: 0.7;border-left:none;padding: 15px;font-size: 15px;
">Capacity Building in IT and Digital Services (including Digital Payments and GST)

                                            </blockquote>

                           

        <div id="page-content-wrapper" style="padding-top: 10px;margin-top: 0px;">
                <div class="page-content" style="margin-top:-20px;">
                                        



                 
                      
                            <!-- ./Messages -->
                        </div>
                        <!-- ./row -->
                    </div>
                   


                    <!-- ./cotainer -->
                </div>

<div class="row" style="margin:10px 30px 10px 30px">
	<div class="col-lg-8 col-md-8">
		
<div class="card shadow">
                                    <div class="card-header">
                                     <!--  <i class="fa fa-building fa-lg"></i>-->
                                        <h2>Monthly Progression Report</h2>
                                    </div>
                                    <div class="card-content">
      
<h5 style="text-align: center;"><u>Monthly Progression Report (2018)</u></h5>
<table class="table table-hover table-striped ">

    <thead>
        <th>S.No</th>
        <th>Month</th>
        <th>Report</th>
    </thead>
    <tbody>
        <tr>
            <td>1.</td>
            <td>&nbsp;January,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Jan2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
        
        <tr>
            <td>2.</td>
            <td>February,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Feb2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
        <tr>
            <td>3.</td>
            <td>&nbsp;&nbsp;&nbsp;March,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Mar2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
        <tr>
            <td>4.</td>
            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;April,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-April2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
        <tr>
            <td>5.</td>
            <td>&nbsp;&nbsp;&nbsp;&nbsp; May,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-May2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
<tr>
            <td>6.</td>
            <td>&nbsp;&nbsp;&nbsp;&nbsp; June,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-June2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
<tr>
            <td>7.</td>
            <td>&nbsp;&nbsp;&nbsp;&nbsp; July,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-July2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
<tr>
            <td>8.</td>
            <td>&nbsp;&nbsp;&nbsp;&nbsp; August,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Aug2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
<tr>
            <td>9.</td>
            <td>September,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Sep2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
<tr>
            <td>10.</td>
            <td>&nbsp;&nbsp; October,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Oct2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
<tr>
            <td>11.</td>
            <td>&nbsp; November,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Nov2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>

<tr>
            <td>12.</td>
            <td>&nbsp; December,&nbsp;2018</td>
            <td><a href="MPR-Report/MPR-Dec2018.pdf" >
            <img src="assets/dist/img/pdf-ico.png" height="25px;">       
            </a>
        </td>
        </tr>
    </tbody>
</table>

</div>
	</div>
	</div>

   

</div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>

        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        
        <div id="footer-abcd" class="dark1">
    <div class="container-fluid">
        <div class="row">
                                                          
                                           <div class="col-sm-4">
                        <aside id="block-region-footer-b" class="footer-b style-bottom block-region" data-blockregion="footer-b" data-droptarget="1">

                            <!--<a href="#sb-10" class="skip-block">Skip Useful Links</a>-->

                            <div id="inst24" class="block_html  block" role="complementary" data-block="html" data-instanceid="24" aria-labelledby="instance-24-header">

                                <div class="header"><div class="title" id="yui_3_17_2_2_1522950294261_36">

                                  

                            <h4 id="instance-24-header">MDoNER</h4></div></div><div class="content"><div class="no-overflow">
                                <p style="text-align: justify;">
                                    The Ministry of Development of North Eastern Region is responsible for the matters relating to the planning, execution and monitoring of development schemes and projects in the North Eastern Region. Its vision is to accelerate the pace of socio-economic development of the Region so that it may enjoy growth parity with the rest of the country.


                                </p>
                                </div></div></div><span id="sb-10" class="skip-block-to"></span></aside>                    

                                </div>                 
                                           
                                                <div class="col-sm-4" style="text-align: center;">
                        <aside id="block-region-footer-b" class="footer-b style-bottom block-region" data-blockregion="footer-b" data-droptarget="1">

                            <!--<a href="#sb-10" class="skip-block">Skip Useful Links</a>-->

                            <div id="inst24" class="block_html  block" role="complementary" data-block="html" data-instanceid="24" aria-labelledby="instance-24-header">

                                <div class="header"><div class="title" id="yui_3_17_2_2_1522950294261_36">

                                   
                            <h4 id="instance-24-header">Useful Links</h4></div></div><div class="content"><div class="no-overflow">
                                <ul class="theme-list list2 list-left" >
                                    <li><a href="http://meity.gov.in" target="_self">MeitY</a></li>
                                    <li><a href="http://mdoner.gov.in" target="_self">MDoNER</a></li>
                                    <li><a href="http://nielit.gov.in" target="_self">NIELIT</a></li>
                                    <li><a href="http://india.gov.in" target="_self">india.gov.in</a></li>
                                    <li><a href="http://digitalindia.gov.in" target="_self">Digital India</a></li></ul></div></div></div><span id="sb-10" class="skip-block-to">                    </div>                 
                                           
                                                <div class="col-sm-4">
                        <aside id="block-region-footer-c" class="footer-c style-bottom block-region" data-blockregion="footer-c" data-droptarget="1">
                            <!--<a href="#sb-11" class="skip-block">Skip Contact</a>-->
                            <div id="inst25" class="block_html  block" role="complementary" data-block="html" data-instanceid="25" aria-labelledby="instance-25-header"><div class="header"><div class="title" id="yui_3_17_2_2_1522950294261_54">
                                <!--<div class="block_action"><img class="block-hider-hide" alt="Hide Contact block" src="http://marbol2.com/themes/cognitio/theme/image.php/mb2cg/core/1520880477/t/switch_minus" tabindex="0" title="Hide Contact block">

                                    <img class="block-hider-show" alt="Show Contact block" src="http://marbol2.com/themes/cognitio/theme/image.php/mb2cg/core/1520880477/t/switch_plus" tabindex="0" title="Show Contact block"></div>
-->
                                    <h4 id="instance-25-header">Contact</h4></div></div><div class="content"><div class="no-overflow"><p>NIELIT Bhawan,
Plot No. 3, PSP Pocket, Sector-8,
Dwarka <br>New Delhi-110077
</p><div class="theme-boxbg boxbg1"><span class="tmpl-icon-wrap" style="display:block;margin:0 0 13px 0;"><i class="tmpl-icon fa fa-envelope icon-size-default" style="color:#fff;"></i><span class="tmpl-icon-content"> &nbsp;doner-pmu@nielit.gov.in</span></span><span class="tmpl-icon-wrap" style="margin:0 20px 0 0;"><i class="tmpl-icon fa fa-phone icon-size-default" style="color:#fff;"></i><span class="tmpl-icon-content"> &nbsp;+91-11-2530 8300</span></span><span class="tmpl-icon-wrap" style=""><i class="tmpl-icon fa fa-print icon-size-default" style="color:#fff;"></i><span class="tmpl-icon-content"> &nbsp;91-11-2436 3335</span></span></div></div></div></div><span id="sb-11" class="skip-block-to"></span></aside>                    </div>                 
                                           
                                                       
                       
        </div>
      
    </div>
</div>
        <footer id="footer" class="dark1">
    <div class="container-fluid">
        <div class="row" style="margin-bottom: 1px">
           
            <div class="col-lg-8">

                <div class="footer-content clearfix">
                  
                    <p class="footer-text" style="color: #fff">Copyright © NIELIT 2018. All rights reserved.</p>
                                                       
                                        
                </div>          
                   
            </div>  
             <div class="col-lg-4" style="margin-top: -20px !important">
     <img src="assets/dist/img/logo_india_gov.png" height="55px" width="160px">
     <img src="assets/dist/img/logo_mygov.png" height="55px" width="80px">
      <!--<img src="assets/dist/img/logo_locker.png" height="55px" width="120px">-->
  
   </div>         
        </div>
    </div>    
</footer>      
        <!-- End Preloader -->

        <!-- Start Core Plugins
             =====================================================================-->
        <!-- jQuery -->
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <!-- materialize  -->
        <!--<script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
         metismenu-master 
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
         SlimScroll -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js 
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins
             =====================================================================-->
        <!-- Start Page Lavel Plugins
             =====================================================================-->
        <!-- Sparkline js -->
        <script src="assets/plugins/sparkline/sparkline.min.js" type="text/javascript"></script>
        <!-- Counter js -->
        <script src="assets/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        <!-- ChartJs JavaScript -->
       
        <!-- End Page Lavel Plugins
             =====================================================================-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js-->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->





  <script type="text/javascript" src="assets/js/vendors/imagesloaded.pkgd.min.js"></script>
    
    <!-- jquery isotop plugin -->
    <script type="text/javascript" src="assets/js/vendors/isotope.pkgd.min.js"></script>

    <!-- jquery history neede for ajax pages -->
    <script type="text/javascript" src="assets/js/vendors/jquery.history.js"></script>

    
    <!-- jquery nice scroll plugin needed for vertical portfolio page -->
    <script type="text/javascript" src="assets/js/vendors/jquery.nicescroll.min.js"></script>

    <!-- jquery magnific popup needed for ligh-boxes -->
    <script type="text/javascript" src="assets/js/vendors/jquery.magnific-popup.js"></script>

    <!-- html5 media player -->
    <script type="text/javascript" src="assets/js/vendors/mediaelement-and-player.min.js"></script>

    <!-- jquery inview plugin -->
    <script type="text/javascript" src="assets/js/vendors/jquery.inview.min.js"></script>

    <!-- smooth scroll -->
    <script type="text/javascript" src="assets/js/vendors/smoothscroll.js"></script>

    

     <!-- theme custom scripts -->
    <script type="text/javascript" src="assets/js/custom.js"></script>



  

      
    </body>

</html>
