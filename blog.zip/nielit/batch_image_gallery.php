
<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Image Batch gallery</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/> 
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css"/>
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css"/>
        <!-- images-grid -->
        <link href="assets/plugins/images-grid/src/images-grid.css" rel="stylesheet" type="text/css"/>
        <!-- lightbox2 -->
        <link href="assets/plugins/lightbox2/dist/css/lightbox.min.css" rel="stylesheet" type="text/css"/>
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">
        <!--<script src="assets/plugins/jQuery/jquery-3.2.1.min.js" type="text/javascript"></script>
        -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js" type="text/javascript"></script>
         <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- materialize  -->
        <script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
        <!-- lightbox2 -->
        <script src="assets/plugins/lightbox2/dist/js/lightbox-plus-jquery.min.js" type="text/javascript"></script>
        <!-- metismenu-master -->
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- images-grid -->
        <script src="assets/plugins/images-grid/src/images-grid.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins-->
        <!-- Start Theme label Script-->
        <!-- main js -->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <link href="assets/prettyphoto/css/prettyPhoto.css" rel="stylesheet"> 
        <script src="assets/prettyphoto/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8">
		</script>
    </head>
   <body>    
		<div id="wrapper">
            <!--navbar top-->
            <nav class="navbar navbar-inverse navbar-fixed-top" style="min-height:75px">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="120" height="80">
                </a>                 
                <ul>
				<li style="color:#000033;" >
    				   		<img src="assets/dist/img/nielit_hindi.png" alt="MDoner" height="25px" width="300px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">National Institute of Electronics & Information Technology, Gangtok
							<br>
								MeitY, Government of India</span>
				</li>
 				<li class="hidden-xs" id="DILogo">
                		<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo"  height="82px" style="" />
                </li>
                </ul>
                <div class="navbar-custom-menu hidden-xs">    
                   <ul class="navbar navbar-right">
                       <li style="color:#000033;" >
    				   		<img src="assets/dist/img/e-waste-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">E-Waste Capacity Building project sponsored by MeitY, Government of India</span>
                       </li>
					   <li style="padding-top: 3px">
					   <img src="emblem.png" width="45" height="75"/>
					   </li>
				   </ul>
                </div>
            </nav>
            <!-- Sidebar -->
           <!-- <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-image: url(assets/dist/img/fabric.png);">-->
           <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-color:#000033;">
             <div class="navbar-default sidebar" role="navigation">
               <div class="sidebar-nav navbar-collapse">
                 <ul class="nav" id="side-menu">
                   <li class="active-link"><a href="dashboard.php"><i class="material-icons">dashboard</i>Home</a></li>
                   <li><a href="about.php"><i class="material-icons">location_city</i>About the Project</a></li>
                   <li><a href="state_org_report.php"><i class="material-icons">location_city</i>Organization Details</a></li>
                   <li><a href="drilldown_report.php"><i class="material-icons">people</i>Candidate Details</a></li>
                   <li><a href="state_tc_report.php"><i class="material-icons">place</i>Training Venue</a></li>
                   <li><a href="state_batch_report.php"><i class="material-icons">dashboard</i>Batch Details</a></li>
                   <li><a href="feedback_consol_report.php"><i class="material-icons">dashboard</i>Feedback Report</a></li>
                   <li><a href="batch_image_gallery.php"><i class="material-icons">image</i>Image Gallery</a></li>
                   <li><a href="feedback-login.php"><i class="material-icons">lock</i>Feedback Login</a></li>
                   <li><a href="administration_login.php"><i class="material-icons">lock</i>Admin Login</a></li>
                   <li class="side-last"></li>
                 </ul>
                 <!-- ./sidebar-nav -->
               </div>
               <!-- ./sidebar -->
             </div>
             <!-- ./sidebar-nav -->
           </div>
           <script>
			   var screen_width = screen.width;
			   var DI_logo_padding =  0;
	
			   if(screen_width>=1300){
				 DI_logo_padding  = (screen_width - 1300)/2;
			   }
			   DI_logo_padding = "2px 0 0 "+DI_logo_padding+"px";
			   document.getElementById("DILogo").style.padding = DI_logo_padding ;
        	</script>
            <!-- ./sidebar-wrapper -->
            <!-- Page content -->
 			<div id="page-content-wrapper"><!--changing purpose-->
				<div class="page-content">
 				<div class="container-fluid">
                        <div class="row">
						<div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 align="center" style="font-style:italic;"><b>E-Waste Capacity Building project sponsored by MeitY</b></h1>
									</div>
								</div>
							</div>
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-toggle-on fa-lg"></i>
                                        <h2>Image Gallery</h2>
                                    </div>
                                    <div class="card-content">
                                        <form class="" method="POST" action="" />
                                                    <select name="tc_centre" onChange="sendRequestdb()" id="tc_centre" class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="display: block">
                                                        <option value="">Select State</option>
                                                        <option value="AR">Arunachal Pradesh</option>
                                                        <option value="AS">Assam</option>
                                                        <option value="MN">Manipur</option>
                                                        <option value="MZ">Mizoram</option>
                                                        <option value="ML">Meghalaya</option>
                                                        <option value="NL">Nagaland</option>
                                                        <option value="SK">Sikkim</option>
                                                        <option value="TR">Tripura</option>
                                                    </select>
                                                   <select id="batch" class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="display: block">
                                                        <option value="">Select Batch</option>
                                                        
                                      </select>
                                                    <input type="submit" onClick="return redirect()" value="Submit" class="btn btn-submit w-md col-lg-2 col-md-2 col-sm-12 col-xs-12" style="margin-left: 10px" />
                                                    
                                                    <br><br>

                                                </form>
                                  </div>

                                </div>
                          </div>
            
      
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                     <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Tripura Batch-317</h2>
                                    </div>
                                    
                                    <div class="card-content">
                                        <div class='list-group gallery' style="width:100%">
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery2]" href="downloads/ImageCompress/Website/2018/317/317_5c383b1e5420e5.15329742.jpg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/317/317_5c383b1e5420e5.15329742.jpg" alt="" /></a>
                                            </div>
                                                                                         <!-- col-6 / end -->
                                            <!-- col-6 / end -->
                                        </div> <!-- list-group / end -->
                                    </div>
                                </div>
                          </div>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                     <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Tripura Batch-316</h2>
                                    </div>
                                    
                                    <div class="card-content">
                                        <div class='list-group gallery' style="width:100%">
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery1]" href="downloads/ImageCompress/Website/2018/316/316_5c382d67d83b01.27446340.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/316/316_5c382d67d83b01.27446340.jpeg" alt="" /></a>
                                            </div>
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery1]" href="downloads/ImageCompress/Website/2018/316/316_5c382d6803c310.13328722.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/316/316_5c382d6803c310.13328722.jpeg" alt="" /></a>
                                            </div>
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery1]" href="downloads/ImageCompress/Website/2018/316/316_5c382d681a71e5.26937288.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/316/316_5c382d681a71e5.26937288.jpeg" alt="" /></a>
                                            </div>
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery1]" href="downloads/ImageCompress/Website/2018/316/316_5c382d68309b70.81268376.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/316/316_5c382d68309b70.81268376.jpeg" alt="" /></a>
                                            </div>
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery1]" href="downloads/ImageCompress/Website/2018/316/316_5c382d68468a24.71000592.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/316/316_5c382d68468a24.71000592.jpeg" alt="" /></a>
                                            </div>
                                                                                         <!-- col-6 / end -->
                                            <!-- col-6 / end -->
                                        </div> <!-- list-group / end -->
                                    </div>
                                </div>
                            </div>

 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                     <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Tripura Batch-313</h2>
                                    </div>
                                    
                                    <div class="card-content">
                                        <div class='list-group gallery' style="width:100%">
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery3]" href="downloads/ImageCompress/Website/2018/313/313_5c36f75f4c41b9.47624442.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/313/313_5c36f75f4c41b9.47624442.jpeg" alt="" /></a>
                                            </div>
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery3]" href="downloads/ImageCompress/Website/2018/313/313_5c36f75f6e3246.82790149.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/313/313_5c36f75f6e3246.82790149.jpeg" alt="" /></a>
                                            </div>
                                                                                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                                                
                                                <a class="fancybox thumbnail example-image-link" rel="prettyPhoto[gallery3]" href="downloads/ImageCompress/Website/2018/313/313_5c36f75f8ed043.80765020.jpeg" data-lightbox="example-1"><img class="example-image" src="downloads/ImageCompress/Website/2018/313/313_5c36f75f8ed043.80765020.jpeg" alt="" /></a>
                                            </div>
                                                                                         <!-- col-6 / end -->
                                            <!-- col-6 / end -->
                                        </div> <!-- list-group / end -->
                                    </div>
                                </div>
                          </div>


    



                           



                                       
        </div>
                  </div>
          </div>
          </div> <!--changing purpose-->
		  
		  


                          
                            <!-- ./Messages -->
    </div>
                        <!-- ./row -->
                    </div>
                   


                    <!-- ./cotainer -->
                </div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Core Plugins
             =====================================================================-->
        <!-- jQuery -->
        <!-- jquery-ui -->
         
    
<script type="text/javascript" charset="utf-8">
            $(document).ready(function(){
                $("area[rel^='prettyPhoto']").prettyPhoto();
                
                $(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: true});
                $(".gallery:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
        
              
            });
            </script>

<script>
    function redirect(){

         var batch_no = document.getElementById("batch").value;
         //alert(batch_no);
       window.location.replace("batch_image_gallery.php?batch_no="+batch_no);
    }

var http = createRequestObject();
//var show_message_div;
function createRequestObject()
{
    var obj;
    var browser = navigator.appName;
    if(browser == "Microsoft Internet Explorer"){
    obj = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else{
    obj = new XMLHttpRequest();
    }
    return obj;   
}
function sendRequestdb()
{
    var cat = document.getElementById('tc_centre').value;
    var QueryString = 'countrystballmain.php?tc_centre='+cat;
    http.open('get', QueryString);
    http.onreadystatechange = handleResponse;
    http.send(null);
}



function handleResponse() {
    if(http.readyState != 4){
    document.body.style.cursor='wait';
    }
    if(http.readyState == 4){
    document.body.style.cursor='';
        var response = http.responseText;
       
       if(response.search("to get batch no") != -1)
       
       {
       response = response.replace("to get batch no", " ");
       document.getElementById('batch').innerHTML = response;
        }
      
      
   
   
   }


}



</script>

    </body>

</html>
