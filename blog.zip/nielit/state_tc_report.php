
<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>State training venue report</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Monthly css -->
        <link href="assets/plugins/monthly/monthly.css" rel="stylesheet" type="text/css" />
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">
         <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css" />
       

  <script src="assets/plugins/jQuery/jquery-3.2.1.min.js" type="text/javascript"></script>
    </head>
   <body>    
		<div id="wrapper">
            <!--navbar top-->
            <nav class="navbar navbar-inverse navbar-fixed-top" style="min-height:75px">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="120" height="80">
                </a>                 
                <ul>
				<li style="color:#000033;" >
    				   		<img src="assets/dist/img/nielit_hindi.png" alt="MDoner" height="25px" width="300px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">National Institute of Electronics & Information Technology, Gangtok
							<br>
								MeitY, Government of India</span>
				</li>
 				<li class="hidden-xs" id="DILogo">
                		<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo"  height="82px" style="" />
                </li>
                </ul>
                <div class="navbar-custom-menu hidden-xs">    
                   <ul class="navbar navbar-right">
                       <li style="color:#000033;" >
    				   		<img src="assets/dist/img/e-waste-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">E-Waste Capacity Building project sponsored by MeitY, Government of India</span>
                       </li>
					   <li style="padding-top: 3px">
					   <img src="emblem.png" width="45" height="75"/>
					   </li>
				   </ul>
                </div>
            </nav>
            <!-- Sidebar -->
           <!-- <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-image: url(assets/dist/img/fabric.png);">-->
           <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-color:#000033;">
             <div class="navbar-default sidebar" role="navigation">
               <div class="sidebar-nav navbar-collapse">
                 <ul class="nav" id="side-menu">
                   <li class="active-link"><a href="dashboard.php"><i class="material-icons">dashboard</i>Home</a></li>
                   <li><a href="about.php"><i class="material-icons">location_city</i>About the Project</a></li>
                   <li><a href="state_org_report.php"><i class="material-icons">location_city</i>Organization Details</a></li>
                   <li><a href="drilldown_report.php"><i class="material-icons">people</i>Candidate Details</a></li>
                   <li><a href="state_tc_report.php"><i class="material-icons">place</i>Training Venue</a></li>
                   <li><a href="state_batch_report.php"><i class="material-icons">dashboard</i>Batch Details</a></li>
                   <li><a href="feedback_consol_report.php"><i class="material-icons">dashboard</i>Feedback Report</a></li>
                   <li><a href="batch_image_gallery.php"><i class="material-icons">image</i>Image Gallery</a></li>
                   <li><a href="feedback-login.php"><i class="material-icons">lock</i>Feedback Login</a></li>
                   <li><a href="administration_login.php"><i class="material-icons">lock</i>Admin Login</a></li>
                   <li class="side-last"></li>
                 </ul>
                 <!-- ./sidebar-nav -->
               </div>
               <!-- ./sidebar -->
             </div>
             <!-- ./sidebar-nav -->
           </div>
           <script>
			   var screen_width = screen.width;
			   var DI_logo_padding =  0;
	
			   if(screen_width>=1300){
				 DI_logo_padding  = (screen_width - 1300)/2;
			   }
			   DI_logo_padding = "2px 0 0 "+DI_logo_padding+"px";
			   document.getElementById("DILogo").style.padding = DI_logo_padding ;
        	</script>
            <!-- ./sidebar-wrapper -->
            <!-- Page content -->
 			<div id="page-content-wrapper"><!--changing purpose-->
				<div class="page-content">
					 <div class="container-fluid">
                        <div class="row">
						<div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 align="center" style="font-style:italic;"><b>E-Waste Capacity Building project sponsored by MeitY</b></h1>
									</div>
								</div>
							</div>
                     	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                         


                                                                                <h2>StateWise Batch Details <a style="float:right" href=PHPExcel/Examples/training-venue_report.php> 
      <img src="assets/dist/img/excel-download-icon.png" title="State Category Gender Wise Report" alt="Excel" height="26" width="26"></a></h2>
        </h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>State</th>
                                                        <th>District Name</th>
                                                        <th>Venue Name</th>
                                                        <th>Venue Address</th>
                                                        <th>Organization Count</th>
                                                        <th>Batch Count</th>
                                                        <th>Candidate Count</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     
                                            <tr>
                                            <td>Tripura</td>
                                            <td>West Tripura</td>
                                            <td>NIELIT Agartala Centre</td>
                                            <td>Bodhjungnagar, R.K Nagar</td>
                                            <td>46</td>
                                            <td>12</td>
                                            <td>360</td>

                                                    </tr>
                                                        <tr>
                                            <td>Sikkim</td>
                                            <td>East Sikkim</td>
                                            <td>NIELIT GANGTOK</td>
                                            <td>Indira By Pass Road, Near KBT Petrol Pump, Sichey, Gangtok-737101</td>
                                            <td>1</td>
                                            <td>8</td>
                                            <td>172</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Kamrup Metro</td>
                                            <td>NIELIT Guwahati</td>
                                            <td>AFC Building , Md shah Road
Paltanbazar, Guwahati-781008
</td>
                                            <td>12</td>
                                            <td>17</td>
                                            <td>688</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Kamrup Metro</td>
                                            <td>NIELIT Guwahati City Centre</td>
                                            <td>2nd Floor, AIRT&SC Building, N.H-37, Jawaharnagar, Khanapara, Guwahati-781022</td>
                                            <td>8</td>
                                            <td>16</td>
                                            <td>487</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Sonitpur</td>
                                            <td>Tezpur EC of NIELIT Guwahati</td>
                                            <td>NIELIT Tezpur`
2nd Floor, ICCW Building, Near Civil Hospital, Tezpur- 784001</td>
                                            <td>46</td>
                                            <td>16</td>
                                            <td>990</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Imphal-East</td>
                                            <td>NIELIT Imphal</td>
                                            <td>NIELIT Imphal 
Akampat, Imphal-795001, Manipur</td>
                                            <td>40</td>
                                            <td>15</td>
                                            <td>342</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Churachandpur</td>
                                            <td>NIELIT Churachandpur</td>
                                            <td>NIELIT Churachandpur Ext. Centre
Churachandpur</td>
                                            <td>10</td>
                                            <td>1</td>
                                            <td>12</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Senapati</td>
                                            <td>NIELIT Senapati</td>
                                            <td>NIELIT Senapati Extension Centre
Angkailongdi, Senapati</td>
                                            <td>15</td>
                                            <td>1</td>
                                            <td>30</td>

                                                    </tr>
                                                        <tr>
                                            <td>Arunachal Pradesh</td>
                                            <td>Papum Pare</td>
                                            <td>NIELIT Itanagar</td>
                                            <td>E-Sector, Near Shiv Mandir
City: Naharlagun
Dist: Papumpare
Arunachal Pradesh- 791110
Contact: 0360-2351854</td>
                                            <td>37</td>
                                            <td>14</td>
                                            <td>232</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Jorhat</td>
                                            <td>NIELIT GUWAHATI JORHAT Extension Centre</td>
                                            <td>NIELIT JORHAT EC,
ISBT 1ST FLOOR,
KOTOKIPUKHURI, Tarajan
Jorhat-785001</td>
                                            <td>65</td>
                                            <td>16</td>
                                            <td>1055</td>

                                                    </tr>
                                                        <tr>
                                            <td>Arunachal Pradesh</td>
                                            <td>East Siang</td>
                                            <td>Pasighat EC of NIELIT Itanagar</td>
                                            <td>U. D. Building, 2nd Floor
Gumin Nagar
Pasighat
Arunachal Pradesh-791102
Land mark: Near Fish Market</td>
                                            <td>33</td>
                                            <td>12</td>
                                            <td>201</td>

                                                    </tr>
                                                        <tr>
                                            <td>Arunachal Pradesh</td>
                                            <td>Lohit</td>
                                            <td>Tezu EC of NIELIT Itanagar</td>
                                            <td>Behind District Industry Office. 
P.O. Tezu
Dist: Lohit
Arunachal Pradesh- 792001
Phone: 03804-224754</td>
                                            <td>31</td>
                                            <td>12</td>
                                            <td>137</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Ukhrul</td>
                                            <td>DC Complex Ukhrul</td>
                                            <td>DC Complex Ukhrul(NIELIT Imphal Study Centre)</td>
                                            <td>23</td>
                                            <td>2</td>
                                            <td>45</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Kokrajhar</td>
                                            <td>Kokrajhar EC of NIELIT Guwahati</td>
                                            <td>NIELIT Kokrajhar
Above SBI north Kokrajhar
J.D. Road
Kokrajhar, Assam</td>
                                            <td>15</td>
                                            <td>16</td>
                                            <td>692</td>

                                                    </tr>
                                                        <tr>
                                            <td>Mizoram</td>
                                            <td>Aizawl</td>
                                            <td>NIELIT Aizawl</td>
                                            <td>Industrial Estate, Zuangtui
Aizawl, Mizoram-796017</td>
                                            <td>63</td>
                                            <td>9</td>
                                            <td>220</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Dibrugarh</td>
                                            <td>Dibrugarh Extension Centre of NIELIT Guwahati</td>
                                            <td>1st Floor, Administrative Block, Lahowal College, Lahoal, Dibrugarh-786010</td>
                                            <td>48</td>
                                            <td>17</td>
                                            <td>1213</td>

                                                    </tr>
                                                        <tr>
                                            <td>Arunachal Pradesh</td>
                                            <td>Papum Pare</td>
                                            <td>NIELIT Study Centre, D. N. Government College, Itanagar</td>
                                            <td>Dera Natung Government College, 
Vivek Vihar, Itanagar
Arunachal Pradesh-791113</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>22</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Cachar</td>
                                            <td>Silchar EC of NIELIT Guwahati</td>
                                            <td>OLD GUEST HOUSE NO 1
NIT CAMPUS SILCHAR
DIST: CACHAR
ASSAM-788010
</td>
                                            <td>25</td>
                                            <td>20</td>
                                            <td>705</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Tamenglong</td>
                                            <td>Tamenglong</td>
                                            <td>Gadailong Primary School, Tamenlong(NIELIT Imphal Study Centre)</td>
                                            <td>10</td>
                                            <td>1</td>
                                            <td>21</td>

                                                    </tr>
                                                        <tr>
                                            <td>Nagaland</td>
                                            <td>Kohima</td>
                                            <td>NIELIT KOHIMA</td>
                                            <td>Mereima</td>
                                            <td>19</td>
                                            <td>6</td>
                                            <td>139</td>

                                                    </tr>
                                                        <tr>
                                            <td>Meghalaya</td>
                                            <td>East Khasi Hills</td>
                                            <td>NIELIT Shillong</td>
                                            <td>NIELIT Shillong
2nd Floor MSHFCS Ltd Building
Behind Bethany Hospital
Nogrim Hills
Shillong :793003
Meghalaya</td>
                                            <td>34</td>
                                            <td>13</td>
                                            <td>230</td>

                                                    </tr>
                                                        <tr>
                                            <td>Nagaland</td>
                                            <td>Mokokchung</td>
                                            <td>NIELIT Chuchuyimlang</td>
                                            <td>Nagaland Gandhi Ashram Chuchuyimlang</td>
                                            <td>7</td>
                                            <td>5</td>
                                            <td>90</td>

                                                    </tr>
                                                        <tr>
                                            <td>Nagaland</td>
                                            <td>Mokokchung</td>
                                            <td>Naga Infotech</td>
                                            <td>Marsosang Complex
Mokokchung</td>
                                            <td>25</td>
                                            <td>3</td>
                                            <td>46</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Imphal-West</td>
                                            <td>Manipur Assembly Secretariat</td>
                                            <td>Manipur Assembly Secretariat, Imphal</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>45</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Kakching</td>
                                            <td>Kakching Khunou College</td>
                                            <td>Kakching Khunou College</td>
                                            <td>5</td>
                                            <td>2</td>
                                            <td>60</td>

                                                    </tr>
                                                        <tr>
                                            <td>Meghalaya</td>
                                            <td>West Jaintia Hills</td>
                                            <td>Kiang Nangbah Govt. College Jowai</td>
                                            <td>Kiang Nangbah Govt. College Jowai</td>
                                            <td>20</td>
                                            <td>3</td>
                                            <td>52</td>

                                                    </tr>
                                                        <tr>
                                            <td>Meghalaya</td>
                                            <td>West Garo Hills</td>
                                            <td>NIELIT Tura Extension centre</td>
                                            <td>NIELIT Tura Extension centre,Tura</td>
                                            <td>16</td>
                                            <td>7</td>
                                            <td>109</td>

                                                    </tr>
                                                        <tr>
                                            <td>Mizoram</td>
                                            <td>Lunglei</td>
                                            <td>NIELIT Lunglei</td>
                                            <td>Pukpui, Lunglei, Mizoram</td>
                                            <td>8</td>
                                            <td>5</td>
                                            <td>37</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Thoubal</td>
                                            <td>DC Thoubal</td>
                                            <td>DC Thoubal Complex</td>
                                            <td>13</td>
                                            <td>1</td>
                                            <td>28</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Barpeta</td>
                                            <td>Barpeta</td>
                                            <td>Baishnab Technologies Pvt Ltd , Barpeta , K K Road, Barpeta , Pin-781301</td>
                                            <td>3</td>
                                            <td>8</td>
                                            <td>185</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Dhemaji</td>
                                            <td>Silapathar</td>
                                            <td>Silapathar, Dhemaji, Pin-787059</td>
                                            <td>4</td>
                                            <td>8</td>
                                            <td>218</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Dhubri</td>
                                            <td>Dhubri</td>
                                            <td>College of Advanced Technical Studies, G.T.B. Road, Dhubri</td>
                                            <td>4</td>
                                            <td>8</td>
                                            <td>146</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Sivasagar</td>
                                            <td>Sivasagar</td>
                                            <td>Global Engineering Academy Babupatty,Ward No-12 Near LIC Sivasagar-785640</td>
                                            <td>40</td>
                                            <td>7</td>
                                            <td>159</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>West Tripura</td>
                                            <td>Women's College, Agartala</td>
                                            <td>B.K. Road, Tripura(West),Pin:799001</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>30</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Biswanath</td>
                                            <td>Biswanath Chariali</td>
                                            <td>1st & 2nd Floor, Kohinoor Complex
College Road
Biswanath- 784176</td>
                                            <td>4</td>
                                            <td>6</td>
                                            <td>222</td>

                                                    </tr>
                                                        <tr>
                                            <td>Manipur</td>
                                            <td>Kangpokpi</td>
                                            <td>NIELIT Study Centre, Kangpokpi</td>
                                            <td>NIELIT Study Centre, Kangpokpi</td>
                                            <td>9</td>
                                            <td>1</td>
                                            <td>18</td>

                                                    </tr>
                                                        <tr>
                                            <td>Meghalaya</td>
                                            <td>South West Khasi Hills</td>
                                            <td>GCIITS Training Center, Mawkyrwat</td>
                                            <td>Mawkyrwat, South West Khasi Hills, Meghalaya</td>
                                            <td>18</td>
                                            <td>3</td>
                                            <td>37</td>

                                                    </tr>
                                                        <tr>
                                            <td>Assam</td>
                                            <td>Majuli</td>
                                            <td>NIELIT MAJULI STUDY CENTRE</td>
                                            <td>Garmur, Majuli</td>
                                            <td>15</td>
                                            <td>4</td>
                                            <td>78</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>North Tripura</td>
                                            <td>O/o The District Magistrate and Collector, North Tripura</td>
                                            <td>O/o the District Magistrate and Collector,Dharmanagar, North Tripura District, PIN : 799250</td>
                                            <td>18</td>
                                            <td>2</td>
                                            <td>35</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Sepahijala</td>
                                            <td>O/o The District Magistrate and Collector, Sepahijala</td>
                                            <td>Bishramganj, Sepahijala District, PIN : 799103</td>
                                            <td>10</td>
                                            <td>2</td>
                                            <td>33</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Gomati</td>
                                            <td>O/o The District Magistrate and Collector, Gomati</td>
                                            <td>Udaipur, R.K Pur, PIN: 799120</td>
                                            <td>14</td>
                                            <td>2</td>
                                            <td>28</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Unakoti</td>
                                            <td>O/o The District Magistrate and Collector, Unakoti</td>
                                            <td>Kailashahar, Unakoti Tripura, Pin-799282</td>
                                            <td>19</td>
                                            <td>2</td>
                                            <td>39</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>South Tripura</td>
                                            <td>O/o The District Magistrate and Collector, South Tripura</td>
                                            <td>South Tripura, Belonia, Pin-799155</td>
                                            <td>13</td>
                                            <td>2</td>
                                            <td>36</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Unakoti</td>
                                            <td>Ambedkar College, Fatikroy</td>
                                            <td>Fatikroy, Unakoti, Tripura,Pin-799290</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>18</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>North Tripura</td>
                                            <td>Government Degree College, Kanchanpur</td>
                                            <td>P.O.: Sukhnacherra - 799271, Kanchanpur, North Tripura</td>
                                            <td>3</td>
                                            <td>1</td>
                                            <td>30</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>South Tripura</td>
                                            <td>Iswar Chandra Vidyasagar College, Belonia</td>
                                            <td>NH-34, Belonia, Tripura,Pin-799155</td>
                                            <td>2</td>
                                            <td>1</td>
                                            <td>41</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>West Tripura</td>
                                            <td>Ramthakur College, Agartala</td>
                                            <td>Badharghat, Agartala, Tripura 799003</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>23</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Gomati</td>
                                            <td>Netaji Subhash Mahavidyalaya, Udaipur</td>
                                            <td>Netaji Subhash Mahavidyalaya, Udaipur, Dist.-Gomoti, Tripura,India</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>19</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>West Tripura</td>
                                            <td>Swami Vivekananda Mahavidyalaya, Mohanpur</td>
                                            <td>Mohanpur, Tripura 799211</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>25</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Khowai</td>
                                            <td>O/o The District Magistrate and Collector, Khowai</td>
                                            <td>Office Tilla, Khowai-799202, Phone: 03825-222004</td>
                                            <td>7</td>
                                            <td>1</td>
                                            <td>13</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Khowai</td>
                                            <td>Dasaratha Deb Memorial College, Khowai</td>
                                            <td>Lalcherra, Khowai. Tripura</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>41</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Dhalai</td>
                                            <td>Government Degree College,Gandacherra</td>
                                            <td>P.O.-Gandacherra,P/S-Gandacherra , 60-Card,Saima,Dhalai Tripura</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>14</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Dhalai</td>
                                            <td>O/o The District Magistrate and Collector, Dhalai</td>
                                            <td>DM Complex, Jawaharnagar, Ambassa, Dhalai District, Tripura – 799289</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>West Tripura</td>
                                            <td>Khumulwng Study Centre of NIELIT Agartala</td>
                                            <td>Near Kokborok Library, Opposite to Thong Thong Hati, Khumulwng, TTAADC, Pin:-799045</td>
                                            <td>12</td>
                                            <td>2</td>
                                            <td>30</td>

                                                    </tr>
                                                        <tr>
                                            <td>Tripura</td>
                                            <td>Sepahijala</td>
                                            <td>Rabindranath Thakur Mahavidyalaya, Bishalgarh</td>
                                            <td>Sepahijala, P.O+P.S-Bishalgarh, Pin-799102</td>
                                            <td>1</td>
                                            <td>1</td>
                                            <td>22</td>

                                                    </tr>
                                                                                                        </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div><!--changing purpose-->

                           



                                       
                                        </div>
                                    </div>
                                </div>
                            </div>


                          
                            <!-- ./Messages -->
                        </div>
                        <!-- ./row -->
                    </div>
                   


                    <!-- ./cotainer -->
                </div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Core Plugins
             =====================================================================-->
        <!-- jQuery -->
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- materialize  -->
        <script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
        <!-- metismenu-master -->
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- SlimScroll -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins
             =====================================================================-->
        <!-- Start Page Lavel Plugins
             =====================================================================-->
        <!-- Sparkline js -->
        <script src="assets/plugins/sparkline/sparkline.min.js" type="text/javascript"></script>
        <!-- Counter js -->
        <script src="assets/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        <!-- ChartJs JavaScript -->
        <script src="assets/plugins/chartJs/Chart.min.js" type="text/javascript"></script>
        <!-- Monthly js -->
        <script src="assets/plugins/monthly/monthly.js" type="text/javascript"></script>

        <!-- End Page Lavel Plugins
             =====================================================================-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js-->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
       
 <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js -->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
        <script>
             "use strict";
            $(document).ready(function () {
                function dtable() {
                    $('#dataTableExample1').DataTable({
                        "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                        "lengthMenu": [
                            [6, 25, 50, -1],
                            [6, 25, 50, "All"]
                        ],
                        "iDisplayLength": 25
                    });
                }
                return (dtable());
            });
        </script>
    




        <script>




            $(document).ready(function () {
                "use strict";
                // Message
                function slscroll() {
                    $('.chat_list , .activity-list , .message_inner').slimScroll({
                        size: '3px',
                        height: '320px',
                        allowPageScroll: true,
                        railVisible: true
                    });
                }
                slscroll();
                function chatscroll() {
                    $('.chat_list').slimScroll({
                        size: '3px',
                        height: '290px'
                    });
                }
                chatscroll();

                //monthly calender
                $('#m_calendar').monthly({
                    mode: 'event',
                    //jsonUrl: 'events.json',
                    //dataType: 'json'
                    xmlUrl: 'events.xml'
                });

                //panel refresh
                $.fn.refreshMe = function (opts) {
                    var $this = this,
                            defaults = {
                                ms: 1500,
                                started: function () {},
                                completed: function () {}
                            },
                            settings = $.extend(defaults, opts);

                    var panelToRefresh = $this.parents('.panel').find('.refresh-container');
                    var dataToRefresh = $this.parents('.panel').find('.refresh-data');
                    var ms = settings.ms;
                    var started = settings.started;		//function before timeout
                    var completed = settings.completed;	//function after timeout

                    $this.click(function () {
                        $this.addClass("fa-spin");
                        panelToRefresh.show();
                        started(dataToRefresh);
                        setTimeout(function () {
                            completed(dataToRefresh);
                            panelToRefresh.fadeOut(800);
                            $this.removeClass("fa-spin");
                        }, ms);
                        return false;
                    });
                };

                $(document).ready(function () {
                    $('.refresh, .refresh2').refreshMe({
                        started: function (ele) {
                            ele.html("Getting new data..");
                        },
                        completed: function (ele) {
                            ele.html("This is the new data after refresh..");
                        }
                    });
                });

                //line chart
                var ctx = document.getElementById("lineChart");
                var myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        datasets: [{
                                label: "Total income",
                                borderColor: "#73879C",
                                borderWidth: "1",
                                backgroundColor: "#73879C",
                                data: [22, 44, 67, 43, 76, 45, 12, 45, 65, 55, 42, 61, 73]
                            }, {
                                label: "Total Expense",
                                borderColor: "rgba(26, 187, 156, 0.64)",
                                borderWidth: "1",
                                backgroundColor: "rgba(26, 187, 156, 0.64)",
                                pointHighlightStroke: "rgba(26, 187, 156, 0.64)",
                                data: [16, 32, 18, 26, 42, 33, 44, 24, 19, 16, 67, 71, 65]
                            }]
                    },
                    options: {
                        responsive: true,
                        tooltips: {
                            mode: 'index',
                            intersect: false
                        },
                        hover: {
                            mode: 'nearest',
                            intersect: true
                        }

                    }
                });

            });
        </script>

 
<!--
 <script src="./dash-home.jsp_files/highcharts.js.download"></script>
<script src="./dash-home.jsp_files/exporting.js.download"></script>
<script src="./dash-home.jsp_files/drilldown.js.download"></script>
<script src="https://code.highcharts.com/modules/heatmap.js"></script>
<script src="https://code.highcharts.com/modules/treemap.js"></script>
-->

    </body>

</html>