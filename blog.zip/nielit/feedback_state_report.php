
<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Feedback</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Monthly css -->
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">
         <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css" />
       

  <script src="assets/plugins/jQuery/jquery-3.2.1.min.js" type="text/javascript"></script>
      


   

    </head>

    <body>    
		<div id="wrapper">
            <!--navbar top-->
            <nav class="navbar navbar-inverse navbar-fixed-top" style="min-height:75px">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="120" height="80">
                </a>                 
                <ul>
				<li style="color:#000033;" >
    				   		<img src="assets/dist/img/nielit_hindi.png" alt="MDoner" height="25px" width="300px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">National Institute of Electronics & Information Technology, Gangtok
							<br>
								MeitY, Government of India</span>
				</li>
 				<li class="hidden-xs" id="DILogo">
                		<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo"  height="82px" style="" />
                </li>
                </ul>
                <div class="navbar-custom-menu hidden-xs">    
                   <ul class="navbar navbar-right">
                       <li style="color:#000033;" >
    				   		<img src="assets/dist/img/e-waste-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">E-Waste Capacity Building project sponsored by MeitY, Government of India</span>
                       </li>
					   <li style="padding-top: 3px">
					   <img src="emblem.png" width="45" height="75"/>
					   </li>
				   </ul>
                </div>
            </nav>
            <!-- Sidebar -->
           <!-- <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-image: url(assets/dist/img/fabric.png);">-->
           <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-color:#000033;">
             <div class="navbar-default sidebar" role="navigation">
               <div class="sidebar-nav navbar-collapse">
                 <ul class="nav" id="side-menu">
                   <li class="active-link"><a href="dashboard.php"><i class="material-icons">dashboard</i>Home</a></li>
                   <li><a href="about.php"><i class="material-icons">location_city</i>About the Project</a></li>
                   <li><a href="state_org_report.php"><i class="material-icons">location_city</i>Organization Details</a></li>
                   <li><a href="drilldown_report.php"><i class="material-icons">people</i>Candidate Details</a></li>
                   <li><a href="state_tc_report.php"><i class="material-icons">place</i>Training Venue</a></li>
                   <li><a href="state_batch_report.php"><i class="material-icons">dashboard</i>Batch Details</a></li>
                   <li><a href="feedback_consol_report.php"><i class="material-icons">dashboard</i>Feedback Report</a></li>
                   <li><a href="batch_image_gallery.php"><i class="material-icons">image</i>Image Gallery</a></li>
                   <li><a href="feedback-login.php"><i class="material-icons">lock</i>Feedback Login</a></li>
                   <li><a href="administration_login.php"><i class="material-icons">lock</i>Admin Login</a></li>
                   <li class="side-last"></li>
                 </ul>
                 <!-- ./sidebar-nav -->
               </div>
               <!-- ./sidebar -->
             </div>
             <!-- ./sidebar-nav -->
           </div>
           <script>
			   var screen_width = screen.width;
			   var DI_logo_padding =  0;
	
			   if(screen_width>=1300){
				 DI_logo_padding  = (screen_width - 1300)/2;
			   }
			   DI_logo_padding = "2px 0 0 "+DI_logo_padding+"px";
			   document.getElementById("DILogo").style.padding = DI_logo_padding ;
        	</script>
            <!-- ./sidebar-wrapper -->
            <!-- Page content -->
 			<div id="page-content-wrapper"><!--changing purpose-->
				<div class="page-content">
					
 <div class="container-fluid">
                        <div class="row">
      <div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 align="center" style="font-style:italic;"><b>E-Waste Capacity Building project sponsored by MeitY</b></h1>
									</div>
								</div>
							</div>                     
 <!--changing purpose--><div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-toggle-on fa-lg"></i>
                                        <h2>Feedback Report</h2>
                                    </div>
                                    <div class="card-content hidden-xs hidden-sm" id="bootstrap-butn">
                                        
                                        <a href="feedback_consol_report.php"  class="btn btn-primary w-md col-lg-4 col-md-4">Consolidated Feedback Report</a> 
                                        <a href="feedback_state_report.php" class="btn btn-success w-md col-lg-4 col-md-4">State Wise Feedback Report</a> 
                                        <a href="batch_feedback_report.php"  class="btn btn-info w-md col-lg-4 col-md-4">Batch Wise overall Feedback report</a> 
                                        <br><br>
                                    </div>
                                    <div class="card-content hidden-lg hidden-md" id="bootstrap-butn">
                                        
                                        <a href="feedback_consol_report.php"  class="btn btn-primary w-md col-sm-12 col-xs-12">Consolidated Feedback Report</a><br><br>
                                        <a href="feedback_state_report.php" class="btn btn-success w-md col-sm-12 col-xs-12">State Wise Feedback Report</a> <br><br>
                                        <a href="batch_feedback_report.php"  class="btn btn-info w-md col-sm-12 col-xs-12">Batch Wise overall Feedback report</a> 
                                        <br><br>
                                    </div>
                                </div>
                            </div>

 
                           
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Arunachal Pradesh)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">592</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">464</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>210</td>
                                                  <td>234</td>
                                                  <td>15</td>
                                                  <td>2</td>  
                                                  <td>3</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>213</td>
                                                  <td>236</td>
                                                  <td>12</td>
                                                  <td>1</td>  
                                                  <td>2</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>192</td>
                                                  <td>243</td>
                                                  <td>29</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>193</td>
                                                  <td>241</td>
                                                  <td>25</td>
                                                  <td>4</td>  
                                                  <td>1</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>187</td>
                                                  <td>243</td>
                                                  <td>31</td>
                                                  <td>3</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>313</td>
                                                  <td>138</td>
                                                  <td>12</td>
                                                  <td>0</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>267</td>
                                                  <td>181</td>
                                                  <td>13</td>
                                                  <td>1</td>  
                                                  <td>2</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>213</td>
                                                  <td>228</td>
                                                  <td>21</td>
                                                  <td>1</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>227</td>
                                                  <td>211</td>
                                                  <td>24</td>
                                                  <td>2</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>209</td>
                                                  <td>225</td>
                                                  <td>24</td>
                                                  <td>5</td>  
                                                  <td>1</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>230</td>
                                                  <td>215</td>
                                                  <td>17</td>
                                                  <td>1</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Assam)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">6838</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">5532</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>2986</td>
                                                  <td>2415</td>
                                                  <td>114</td>
                                                  <td>14</td>  
                                                  <td>3</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>2570</td>
                                                  <td>2768</td>
                                                  <td>178</td>
                                                  <td>13</td>  
                                                  <td>3</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>2422</td>
                                                  <td>2789</td>
                                                  <td>300</td>
                                                  <td>18</td>  
                                                  <td>3</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>2599</td>
                                                  <td>2615</td>
                                                  <td>277</td>
                                                  <td>36</td>  
                                                  <td>5</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>3002</td>
                                                  <td>2241</td>
                                                  <td>263</td>
                                                  <td>23</td>  
                                                  <td>3</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>4069</td>
                                                  <td>1329</td>
                                                  <td>115</td>
                                                  <td>18</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>3526</td>
                                                  <td>1902</td>
                                                  <td>93</td>
                                                  <td>5</td>  
                                                  <td>6</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>2813</td>
                                                  <td>2487</td>
                                                  <td>215</td>
                                                  <td>16</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>3100</td>
                                                  <td>2242</td>
                                                  <td>174</td>
                                                  <td>11</td>  
                                                  <td>5</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>2715</td>
                                                  <td>2480</td>
                                                  <td>297</td>
                                                  <td>34</td>  
                                                  <td>6</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>2718</td>
                                                  <td>2600</td>
                                                  <td>206</td>
                                                  <td>7</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Manipur)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">601</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">539</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>224</td>
                                                  <td>295</td>
                                                  <td>18</td>
                                                  <td>1</td>  
                                                  <td>1</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>187</td>
                                                  <td>334</td>
                                                  <td>17</td>
                                                  <td>0</td>  
                                                  <td>1</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>175</td>
                                                  <td>324</td>
                                                  <td>39</td>
                                                  <td>0</td>  
                                                  <td>1</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>174</td>
                                                  <td>319</td>
                                                  <td>43</td>
                                                  <td>0</td>  
                                                  <td>3</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>153</td>
                                                  <td>313</td>
                                                  <td>58</td>
                                                  <td>13</td>  
                                                  <td>2</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>291</td>
                                                  <td>238</td>
                                                  <td>6</td>
                                                  <td>3</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>252</td>
                                                  <td>271</td>
                                                  <td>15</td>
                                                  <td>0</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>229</td>
                                                  <td>285</td>
                                                  <td>23</td>
                                                  <td>1</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>230</td>
                                                  <td>273</td>
                                                  <td>35</td>
                                                  <td>0</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>191</td>
                                                  <td>295</td>
                                                  <td>46</td>
                                                  <td>5</td>  
                                                  <td>2</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>240</td>
                                                  <td>278</td>
                                                  <td>20</td>
                                                  <td>0</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Meghalaya)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">428</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">428</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>180</td>
                                                  <td>224</td>
                                                  <td>20</td>
                                                  <td>4</td>  
                                                  <td>0</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>192</td>
                                                  <td>224</td>
                                                  <td>10</td>
                                                  <td>2</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>176</td>
                                                  <td>232</td>
                                                  <td>18</td>
                                                  <td>1</td>  
                                                  <td>1</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>200</td>
                                                  <td>204</td>
                                                  <td>21</td>
                                                  <td>2</td>  
                                                  <td>1</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>206</td>
                                                  <td>190</td>
                                                  <td>26</td>
                                                  <td>6</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>261</td>
                                                  <td>162</td>
                                                  <td>2</td>
                                                  <td>2</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>225</td>
                                                  <td>196</td>
                                                  <td>2</td>
                                                  <td>5</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>209</td>
                                                  <td>202</td>
                                                  <td>12</td>
                                                  <td>5</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>246</td>
                                                  <td>175</td>
                                                  <td>4</td>
                                                  <td>3</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>230</td>
                                                  <td>193</td>
                                                  <td>1</td>
                                                  <td>4</td>  
                                                  <td>0</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>217</td>
                                                  <td>194</td>
                                                  <td>16</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Mizoram)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">257</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">226</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>99</td>
                                                  <td>124</td>
                                                  <td>3</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>94</td>
                                                  <td>122</td>
                                                  <td>10</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>85</td>
                                                  <td>129</td>
                                                  <td>12</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>86</td>
                                                  <td>116</td>
                                                  <td>23</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>102</td>
                                                  <td>112</td>
                                                  <td>11</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>168</td>
                                                  <td>54</td>
                                                  <td>3</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>149</td>
                                                  <td>73</td>
                                                  <td>4</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>105</td>
                                                  <td>115</td>
                                                  <td>6</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>106</td>
                                                  <td>109</td>
                                                  <td>11</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>86</td>
                                                  <td>118</td>
                                                  <td>21</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>140</td>
                                                  <td>83</td>
                                                  <td>3</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Nagaland)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">275</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">229</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>111</td>
                                                  <td>111</td>
                                                  <td>7</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>99</td>
                                                  <td>122</td>
                                                  <td>8</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>75</td>
                                                  <td>143</td>
                                                  <td>11</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>94</td>
                                                  <td>116</td>
                                                  <td>19</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>90</td>
                                                  <td>125</td>
                                                  <td>14</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>154</td>
                                                  <td>72</td>
                                                  <td>3</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>130</td>
                                                  <td>96</td>
                                                  <td>3</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>99</td>
                                                  <td>126</td>
                                                  <td>4</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>110</td>
                                                  <td>110</td>
                                                  <td>9</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>104</td>
                                                  <td>112</td>
                                                  <td>13</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>124</td>
                                                  <td>103</td>
                                                  <td>2</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Sikkim)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">172</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">171</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>131</td>
                                                  <td>40</td>
                                                  <td>0</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>123</td>
                                                  <td>47</td>
                                                  <td>1</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>124</td>
                                                  <td>46</td>
                                                  <td>1</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>120</td>
                                                  <td>50</td>
                                                  <td>1</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>141</td>
                                                  <td>26</td>
                                                  <td>4</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>150</td>
                                                  <td>21</td>
                                                  <td>0</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>140</td>
                                                  <td>31</td>
                                                  <td>0</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>127</td>
                                                  <td>41</td>
                                                  <td>3</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>134</td>
                                                  <td>36</td>
                                                  <td>1</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>141</td>
                                                  <td>28</td>
                                                  <td>2</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>126</td>
                                                  <td>42</td>
                                                  <td>3</td>
                                                  <td>0</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report (Tripura)</h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                              	<th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">837</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">757</span></th>
                                              </thead>
                                              
                                              <thead>
                                                  <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>407</td>
                                                  <td>301</td>
                                                  <td>44</td>
                                                  <td>2</td>  
                                                  <td>3</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>357</td>
                                                  <td>365</td>
                                                  <td>34</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>359</td>
                                                  <td>352</td>
                                                  <td>43</td>
                                                  <td>2</td>  
                                                  <td>1</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>376</td>
                                                  <td>322</td>
                                                  <td>55</td>
                                                  <td>2</td>  
                                                  <td>2</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>363</td>
                                                  <td>327</td>
                                                  <td>51</td>
                                                  <td>13</td>  
                                                  <td>3</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>518</td>
                                                  <td>219</td>
                                                  <td>19</td>
                                                  <td>1</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>432</td>
                                                  <td>288</td>
                                                  <td>34</td>
                                                  <td>2</td>  
                                                  <td>1</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>347</td>
                                                  <td>346</td>
                                                  <td>62</td>
                                                  <td>2</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>360</td>
                                                  <td>339</td>
                                                  <td>56</td>
                                                  <td>2</td>  
                                                  <td>0</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>316</td>
                                                  <td>374</td>
                                                  <td>62</td>
                                                  <td>4</td>  
                                                  <td>1</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>395</td>
                                                  <td>332</td>
                                                  <td>26</td>
                                                  <td>2</td>  
                                                  <td>2</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                            </div>

 

                                       
                                        </div>
                                    </div>
                                </div>
                            </div> <!--changing purpose-->


                          
                            <!-- ./Messages -->
                        </div>
                        <!-- ./row -->
                    </div>
                   


                    <!-- ./cotainer -->
                </div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Core Plugins
             =====================================================================-->
        <!-- jQuery -->
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- materialize  -->
        <script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
        <!-- metismenu-master -->
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- SlimScroll -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins
             =====================================================================-->
        <!-- Start Page Lavel Plugins
             =====================================================================-->
        <!-- Sparkline js -->
        <script src="assets/plugins/sparkline/sparkline.min.js" type="text/javascript"></script>
        <!-- Counter js -->
        <!-- ChartJs JavaScript -->
        
        <!-- End Page Lavel Plugins
             =====================================================================-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js-->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
       
 <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js -->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
        




 

    </body>

</html>