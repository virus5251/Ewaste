/*
JavaScript Document (using jQuery Framework)
Developed for the website of NIELIT Agartala Centre
By: Er. Ratnajit Chakma, Guest Faculty of NIELIT Agartala Centre
Batch of 2nd Bachelor (2012 Passout) of Tripura Institute of Technology, Agartala
*/

var count_register=0,
	count_new_jobs=0,
	arr=new Array('', '', ''),
	i=0;
	
var loc=window.location.pathname;

$(function(){
	//news_n_events(); blink_text();
	
	$('.disabled_javascript').hide();
	
	$(document).bind('contextmenu',function(e){
		//alert('Right Click/Context Menu is not allowed!');
		//return false;
	});
	
	$('body').keydown(function(event){
		if(event.keyCode==123){
			//return false;
		}
		if(event.keyCode==17){
			//alert('\'Ctrl\' key is not expected!');
			//return false;
		}
	});
	
	////////////////////////////////////////////////////////////////
	
	$('#input-query').click(function(){
		$('#input-query').css({'color' : '#000'});
		
		if(trim($('#input-query').val())=='Type and press Enter to search'){
			$('#input-query').val('');
		}
	});
	
	$('#input-query').blur(function(){
		if(trim($('#input-query').val())==''){
			$('#input-query').css({'color' : '#777'});
			$('#input-query').val('Type and press Enter to search');
		}
		else{
			$('#input-query').css({'color' : '#000'});
		}
	});
	
	////////////////////////////////////////////////////////////////
	
	$('#event-name').html('<option>---</option>');
	
	$('#event-year').change(function(){
		if(trim($('#event-year').val())!='---' || trim($('#event-year').val())!=''){
			$.get('/cybersecawareness/retrieveEventName.php',{
				  q : trim($('#event-year').val())
				  },
				  function(data, status){
					  if(status=='success'){
						  $('#event-name').html('<option>---</option>' + data);
					  }
					  else{
						  $('#event-name').html('<option>---</option>');
					  }
				  });
		}
		else{
			$('#event-name').html('<option>---</option>');
		}
	});
});


function css_for_menu_item(id){
	$('#' + id + ' a').css({'color' : '#f6d19d', 'background-image' : 'url(/images/for_interface/up-arrow.png)', 'background-position' : 'bottom', 'background-repeat' : 'no-repeat'});
}

function css_for_menu_item_submenu(id){
	$('#' + id + ' .menu-item-submenu-title').css({'color' : '#f6d19d', 'background-image' : 'url(/images/for_interface/up-arrow.png)', 'background-position' : 'bottom', 'background-repeat' : 'no-repeat'});
}

function css_style_with_text_color(id){
	
	$('#' + id + ' a').css({'color' : '#f6d19d', 'border-right' : '2px solid #f6d19d'});
}
	
/////////////////////////////////////////////////////////////////

function blink_text(){
	if(count_register==0){
		$('#link-register-now span').css({'color' : '#000'});
		count_register=1;
	}
	else{
		$('#link-register-now span').css({'color' : '#F30'});
		count_register=0;
	}
	setTimeout("blink_text()", 500);
}

function news_n_events(){
	$('#news-n-events').text(arr[i++]);
	if(i>=arr.length)
		i=0;
	setTimeout('news_n_events()',3000);
}

function _externalLink(href){
	var agreement=confirm('This link will take you to an external website. We are not responsible for their content.');
	if(agreement){
		var win=window.open(href, '_blank');
		win.focus();
	}
	else{
		// Do nothing
	}
}