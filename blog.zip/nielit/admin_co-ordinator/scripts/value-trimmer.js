/*
JavaScript Document (using jQuery Framework)
Leading and Trailing White Space Trimmer
Developed for the website of NIELIT Agartala Centre
By: Er. Ratnajit Chakma, Guest Faculty of NIELIT Agartala Centre
Batch of 2nd Bachelor (2012 Passout) of Tripura Institute of Technology, Agartala
*/

function trim(val)
{
   var i;
   var value=val;
   for(i=0;i<value.length;i++)
      if(value.charAt(i)==" ")
         val=val.replace(" ","");
	  else
	     break;
	
   value=val;
   val="";
   
   for(i=(value.length)-1;i>=0;i--)
      if(value.charAt(i)==" ")
	  {
		  for(j=0;j<i;j++)
		    val=val+value.charAt(j);
		  value=val;
		  val="";
	  }
	  else
	     break;
		 
   if(val=="")
      val=value;
	  
   return val;
}