
<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Feedback</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Monthly css -->
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">
         <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css" />
       

  <script src="assets/plugins/jQuery/jquery-3.2.1.min.js" type="text/javascript">
  </script>
    </head>
    <body>    
		<div id="wrapper">
            <!--navbar top-->
            <nav class="navbar navbar-inverse navbar-fixed-top" style="min-height:75px">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="120" height="80">
                </a>                 
                <ul>
				<li style="color:#000033;" >
    				   		<img src="assets/dist/img/nielit_hindi.png" alt="MDoner" height="25px" width="300px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">National Institute of Electronics & Information Technology, Gangtok
							<br>
								MeitY, Government of India</span>
				</li>
 				<li class="hidden-xs" id="DILogo">
                		<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo"  height="82px" style="" />
                </li>
                </ul>
                <div class="navbar-custom-menu hidden-xs">    
                   <ul class="navbar navbar-right">
                       <li style="color:#000033;" >
    				   		<img src="assets/dist/img/e-waste-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">E-Waste Capacity Building project sponsored by MeitY, Government of India</span>
                       </li>
					   <li style="padding-top: 3px">
					   <img src="emblem.png" width="45" height="75"/>
					   </li>
				   </ul>
                </div>
            </nav>
            <!-- Sidebar -->
           <!-- <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-image: url(assets/dist/img/fabric.png);">-->
           <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-color:#000033;">
             <div class="navbar-default sidebar" role="navigation">
               <div class="sidebar-nav navbar-collapse">
                 <ul class="nav" id="side-menu">
                   <li class="active-link"><a href="dashboard.php"><i class="material-icons">dashboard</i>Home</a></li>
                   <li><a href="about.php"><i class="material-icons">location_city</i>About the Project</a></li>
                   <li><a href="state_org_report.php"><i class="material-icons">location_city</i>Organization Details</a></li>
                   <li><a href="drilldown_report.php"><i class="material-icons">people</i>Candidate Details</a></li>
                   <li><a href="state_tc_report.php"><i class="material-icons">place</i>Training Venue</a></li>
                   <li><a href="state_batch_report.php"><i class="material-icons">dashboard</i>Batch Details</a></li>
                   <li><a href="feedback_consol_report.php"><i class="material-icons">dashboard</i>Feedback Report</a></li>
                   <li><a href="batch_image_gallery.php"><i class="material-icons">image</i>Image Gallery</a></li>
                   <li><a href="feedback-login.php"><i class="material-icons">lock</i>Feedback Login</a></li>
                   <li><a href="administration_login.php"><i class="material-icons">lock</i>Admin Login</a></li>
                   <li class="side-last"></li>
                 </ul>
                 <!-- ./sidebar-nav -->
               </div>
               <!-- ./sidebar -->
             </div>
             <!-- ./sidebar-nav -->
           </div>
           <script>
			   var screen_width = screen.width;
			   var DI_logo_padding =  0;
	
			   if(screen_width>=1300){
				 DI_logo_padding  = (screen_width - 1300)/2;
			   }
			   DI_logo_padding = "2px 0 0 "+DI_logo_padding+"px";
			   document.getElementById("DILogo").style.padding = DI_logo_padding ;
        	</script>
            <!-- ./sidebar-wrapper -->
            <!-- Page content -->
 			<div id="page-content-wrapper"><!--changing purpose-->
				<div class="page-content">
					
 <div class="container-fluid">
                        <div class="row">
                          <div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 align="center" style="font-style:italic;"><b>E-Waste Capacity Building project sponsored by MeitY</b></h1>
									</div>
								</div>
							</div> 
      
 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <!--changing purpose--> <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-toggle-on fa-lg"></i>
                                        <h2>Feedback Report</h2>
                                    </div>
                                    <div class="card-content hidden-xs hidden-sm" id="bootstrap-butn">
                                        
                                        <a href="feedback_consol_report.php"  class="btn btn-primary w-md col-lg-4 col-md-4">Consolidated Feedback Report</a> 
                                        <a href="feedback_state_report.php" class="btn btn-success w-md col-lg-4 col-md-4">State Wise Feedback Report</a> 
                                        <a href="batch_feedback_report.php"  class="btn btn-info w-md col-lg-4 col-md-4">Batch Wise Overall Feedback report</a> 
                                        <br><br>
                                    </div>
                                    <div class="card-content hidden-lg hidden-md" id="bootstrap-butn">
                                        
                                        <a href="feedback_consol_report.php"  class="btn btn-primary w-md col-sm-12 col-xs-12">Consolidated Feedback Report</a><br><br>
                                        <a href="feedback_state_report.php" class="btn btn-success w-md col-sm-12 col-xs-12">State Wise Feedback Report</a> <br><br>
                                        <a href="batch_feedback_report.php"  class="btn btn-info w-md col-sm-12 col-xs-12">Batch Wise  Overall Feedback report</a> 
                                        <br><br>
                                    </div>
                                </div>
                          </div>

                           
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-table fa-lg"></i>
                                        <h2>Feedback Consolidated Report </h2>
                                    </div>
                                    <div class="card-content">
                                        <div class="table-responsive">
                                            
                                            
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                              <thead>
                                           	  <th colspan="2">Total Trained Candidate: <span style="color: #b34a5c">10000</span></th>
                                              	<th colspan="5">Total Feedback Count :  <span style="color: #b34a5c">8346</span></th>
                                              </thead>
                                              
                                              <thead>
                                              <th>S. No</th>
                                                  <th>Please indicate your impressions of the items listed below.</th>
                                                  <th>Strongly Agree</th>
                                                  <th>Agree</th>
                                                  <th>Neutral</th>
                                                  <th>Disagree</th>
                                                  <th>Strongly Disagree</th>
                                              </thead>



                                              <tr>
                                                  <td>1. </td>
                                                  <td>The training met my expectations </td>
                                                  <td>4348</td>
                                                  <td>3744</td>
                                                  <td>221</td>
                                                  <td>23</td>  
                                                  <td>10</td>
                                              </tr>
                                           <tr>
                                                <td>2. </td>
                                                  <td>I will be able to apply the knowledge learned </td>
                                                 <td>3835</td>
                                                  <td>4218</td>
                                                  <td>270</td>
                                                  <td>17</td>  
                                                  <td>6</td>
                                              </tr>
                                                  
                                                  </tr>
                                               <tr>
                                                <td>3. </td>
                                                  <td>The training objectives for each topic were identified and followed </td>
                                                   <td>3608</td>
                                                  <td>4258</td>
                                                  <td>453</td>
                                                  <td>21</td>  
                                                  <td>6</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>4. </td>
                                                  <td>The content was organized and easy to follow </td>
                                                  <td>3842</td>
                                                  <td>3983</td>
                                                  <td>464</td>
                                                  <td>45</td>  
                                                  <td>12</td>
                                              </tr>
                                                  
                                              </tr>
                                              <tr>
                                                <td>5. </td>
                                                  <td>The materials distributed were pertinent and useful </td>
                                                   <td>4244</td>
                                                  <td>3577</td>
                                                  <td>458</td>
                                                  <td>59</td>  
                                                  <td>8</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>6. </td>
                                                  <td>The trainer was knowledgeable </td>
                                                  <td>5924</td>
                                                  <td>2233</td>
                                                  <td>160</td>
                                                  <td>25</td>  
                                                  <td>4</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>7. </td>
                                                  <td>The quality of instruction was good </td>
                                                  <td>5121</td>
                                                  <td>3038</td>
                                                  <td>164</td>
                                                  <td>13</td>  
                                                  <td>10</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>8. </td>
                                                  <td>The trainer met the training objectives </td>
                                                   <td>4142</td>
                                                  <td>3830</td>
                                                  <td>346</td>
                                                  <td>25</td>  
                                                  <td>3</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>9. </td>
                                                  <td>Class participation and interaction were encouraged </td>
                                                   <td>4513</td>
                                                  <td>3495</td>
                                                  <td>314</td>
                                                  <td>18</td>  
                                                  <td>6</td>
                                              </tr>
                                              </tr>
                                              <tr>
                                                <td>10. </td>
                                                  <td>Adequate time was provided for questions and discussion </td>
                                                   <td>3992</td>
                                                  <td>3825</td>
                                                  <td>466</td>
                                                  <td>53</td>  
                                                  <td>10</td>
                                              </tr>
                                            <tr>
                                                <th></th>
                                                  <th></th>
                                                  <th>Excellent</th>
                                                  <th>Good</th>
                                                  <th>Average</th>
                                                  <th>Poor</th>
                                                  <th>Very Poor</th>
                                            </tr>
                                    <tr>
                                                  <td>11</td>
                                                  <td>How do you rate the training overall? </td>
                                                   <td>4190</td>
                                                  <td>3847</td>
                                                  <td>293</td>
                                                  <td>11</td>  
                                                  <td>5</td>
                                              </tr>
                                              </tr>



                            </table>
                            <br><br>


                  
   



                                        </div>
                                    </div>
                                </div>
                          </div><!--changing purpose-->

 


                                       
        </div>
                  </div>
         </div>
          </div>


                          
                            <!-- ./Messages -->
    </div>
                        <!-- ./row -->
                    </div>
                   


                    <!-- ./cotainer -->
                </div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Core Plugins
             =====================================================================-->
        <!-- jQuery -->
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- materialize  -->
        <script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
        <!-- metismenu-master -->
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- SlimScroll -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins
             =====================================================================-->
        <!-- Start Page Lavel Plugins
             =====================================================================-->
        <!-- Sparkline js -->
        <script src="assets/plugins/sparkline/sparkline.min.js" type="text/javascript"></script>
        <!-- Counter js -->
        <!-- ChartJs JavaScript -->
        
        <!-- End Page Lavel Plugins
             =====================================================================-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js-->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
       
 <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js -->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
        




 

    </body>

</html>