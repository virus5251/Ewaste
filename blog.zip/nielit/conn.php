<?php 
$conn=mysqli_connect("localhost","root","","ewaste_gangtok");
?>
