
<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>About DoNER Project</title>
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/fav.png">
        <!-- Start Global Mandatory Style
             =====================================================================-->
        <!-- jquery-ui css -->
        <link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <!-- materialize css -->
        <link href="assets/plugins/materialize/css/materialize.min.css" rel="stylesheet">
        <!-- Bootstrap css-->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Animation Css -->
        <link href="assets/plugins/animate/animate.css" rel="stylesheet" />
        <!-- Material Icons CSS -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Monthly css -->
        <link href="assets/plugins/monthly/monthly.css" rel="stylesheet" type="text/css" />
        <!-- simplebar scroll css -->
        <link href="assets/plugins/simplebar/dist/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- mCustomScrollbar css -->
        <link href="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
        <!-- custom CSS -->
        <link href="assets/dist/css/stylematerial.css" rel="stylesheet">
         <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css" />
       

  <script src="assets/plugins/jQuery/jquery-3.2.1.min.js" type="text/javascript"></script>

<style>
    
    li{
       /* margin-left: 15px;*/
    }
    .fontsix{
        font-weight: 600;
    } 
</style>
    </head>
  <body>    
		<div id="wrapper">
            <!--navbar top-->
            <nav class="navbar navbar-inverse navbar-fixed-top" style="min-height:75px">
                <!-- Logo -->
                <a class="navbar-brand pull-left" href="#">
                   <img src="assets/dist/img/NIELIT-Logo.png" alt="NIELIT logo" width="120" height="80">
                </a>                 
                <ul>
				<li style="color:#000033;" >
    				   		<img src="assets/dist/img/nielit_hindi.png" alt="MDoner" height="25px" width="300px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">National Institute of Electronics & Information Technology, Gangtok
							<br>
								MeitY, Government of India</span>
				</li>
 				<li class="hidden-xs" id="DILogo">
                		<img src="assets/dist/img/digital-india-logo.jpg" alt="digital-india-logo"  height="82px" style="" />
                </li>
                </ul>
                <div class="navbar-custom-menu hidden-xs">    
                   <ul class="navbar navbar-right">
                       <li style="color:#000033;" >
    				   		<img src="assets/dist/img/e-waste-logo.png" alt="MDoner" height="40px" width="500px" style="margin-top:10px;padding-top: 5px">
					   		<br>
					   			<span style="float:right;padding-right:10px;font-size: 12px;">E-Waste Capacity Building project sponsored by MeitY, Government of India</span>
                       </li>
					   <li style="padding-top: 3px">
					   <img src="emblem.png" width="45" height="75"/>
					   </li>
				   </ul>
                </div>
            </nav>
            <!-- Sidebar -->
           <!-- <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-image: url(assets/dist/img/fabric.png);">-->
           <div id="sidebar-wrapper" class="waves-effect" data-simplebar style="background-color:#000033;">
             <div class="navbar-default sidebar" role="navigation">
               <div class="sidebar-nav navbar-collapse">
                 <ul class="nav" id="side-menu">
                   <li class="active-link"><a href="dashboard.php"><i class="material-icons">dashboard</i>Home</a></li>
                   <li><a href="about.php"><i class="material-icons">location_city</i>About the Project</a></li>
                   <li><a href="state_org_report.php"><i class="material-icons">location_city</i>Organization Details</a></li>
                   <li><a href="drilldown_report.php"><i class="material-icons">people</i>Candidate Details</a></li>
                   <li><a href="state_tc_report.php"><i class="material-icons">place</i>Training Venue</a></li>
                   <li><a href="state_batch_report.php"><i class="material-icons">dashboard</i>Batch Details</a></li>
                   <li><a href="feedback_consol_report.php"><i class="material-icons">dashboard</i>Feedback Report</a></li>
                   <li><a href="batch_image_gallery.php"><i class="material-icons">image</i>Image Gallery</a></li>
                   <li><a href="feedback-login.php"><i class="material-icons">lock</i>Feedback Login</a></li>
                   <li><a href="administration_login.php"><i class="material-icons">lock</i>Admin Login</a></li>
                   <li class="side-last"></li>
                 </ul>
                 <!-- ./sidebar-nav -->
               </div>
               <!-- ./sidebar -->
             </div>
             <!-- ./sidebar-nav -->
           </div>
           <script>
			   var screen_width = screen.width;
			   var DI_logo_padding =  0;
	
			   if(screen_width>=1300){
				 DI_logo_padding  = (screen_width - 1300)/2;
			   }
			   DI_logo_padding = "2px 0 0 "+DI_logo_padding+"px";
			   document.getElementById("DILogo").style.padding = DI_logo_padding ;
        	</script>
            <!-- ./sidebar-wrapper -->
            <!-- Page content -->
 			<div id="page-content-wrapper"><!--changing purpose-->
				<div class="page-content">
					<div class="container-fluid">
                        <div class="row">
							<div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h1 align="center" style="font-style:italic;"><b>E-Waste Capacity Building project sponsored by MeitY</b></h1>
									</div>
								</div>
							</div>
							
                        	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="card">
                                    <div class="card-header">
                                        <i class="fa fa-building fa-lg"></i>
                                        
                                        <h2>About The Project</h2>
                                    </div>
                                    <div class="card-content">
                                        <ul class="nav nav-pills">
                                            <li class="active"><a data-toggle="pill" href="#home">Project</a></li>
                                            <li ><a data-toggle="pill" href="#course">Course Structure</a></li>
                                            <li><a data-toggle="pill" href="#target">Targets</a></li>
                                            <!--<li><a data-toggle="pill" href="#document">Documents</a></li>-->
                                            
                                        </ul>

                                        <div class="tab-content">
                                            <div id="home" class="tab-pane fade in active">
                                                <br>
                                                <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Title of the Project</blockquote>

                                               
                                                <h4 ><span style="font-weight:600">Capacity Building in IT and Digital Services (Including Digital Payments and GST) for State Govt Officials in NER </span></h4>
                                                <p>The course comprises of modules on Computer Concepts (CCC- Course on Computer Concepts),a course on Digital Literacy with additional modules on, Digital Payment, GST Training and e-Governance Services. It consists of 98 hours of course curriculum delivered over a 7 hour schedule daily for 14 days comprising of theory and practical classes.</p>
                                                <p>Course on Computer Concepts will aim to provide the participants with an understanding of digital instruments needed regularly in official work such as word, excel, power-point, email and internet browsing.</p>
                                                <p>The Digital Payments module will cover understanding of USSD, UPI, e-wallet, AEPS, Card, PoS, internet banking and online transactions. As the thrust of the Government on promoting cashless transactions through mobile phones is increasing, the course will provide hands-on experiences through DIY (Do it yourself) to carry out cashless transactions using digital financial tools. Cyber safety measures will form an important element of the training program.</p>
                                                <p>The GST Skills Training module will cover important elements ensuring complete understanding and ease in use of GST; such as GST Registration, migration of existing tax payer, transition to GST, log in and other details, personalisation, uploading credentials and business details, filing returns, penalties, appeals etc.</p><br>
                                               <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Aims &amp; Objectives</blockquote>
 <ul>
                                                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  To enhance the IT skills of fifty thousand state govt officials of NER by providing them with digital skills viz; digital literacy, digital payments, e- governance services and GST training</li>
                                                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  To facilitate adoption as well as regular use of IT and Digital Services as a way of life, and especially in official work. </li>
                                                </ul><br>
  <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Location of Project</blockquote>
   
    <p>The project will be implemented through the NIELIT network in NER comprising of NIELIT’s own centres which are operational in each state capital and major cities and a network of other centres classified as NIELIT extension centres, NIELIT accreditation centres and NIELIT facilitation centres. In total NIELIT has a network of 571 centres in NE Region. It will be NIELIT’s endeavour to conduct maximum trainings at NIELIT’s own centres/extension centres. </p> <br>

    <h4>Details of NIELIT’s own and extension centres are as under: </h4>
    <table class="table table-striped table-bordered table-hover">
        <tr>
            <th>S. No</th>
            <th>State</th>
            <th>Number of NIELIT’s own centres</th>
            <th>Locations</th>
        </tr>
        <tr>
            <td>1</td>
            <td>Arunachal Pradesh</td>
            <td>3</td>
            <td>Itanagar, Tezu and Pasighat</td>
        </tr>
<tr>
            <td>2</td>
            <td>Assam</td>
            <td>6</td>
            <td>Guwahati, Dibrugarh, Jorhat, Tezpur, Silchar, Kokrajhar  </td>
        </tr><tr>
            <td>3</td>
            <td>Manipur</td>
            <td>3</td>
            <td>Imphal, Churachandpur, and Senapati </td>
        </tr><tr>
            <td>4</td>
            <td>Meghalaya</td>
            <td>2</td>
            <td>Shillong and Tura </td>
        </tr><tr>
            <td>5</td>
            <td>Mizoram</td>
            <td>2</td>
            <td>Aizwal, Lunglei </td>
        </tr><tr>
            <td>6</td>
            <td>Nagaland</td>
            <td>2 + 4 Centres on project mode for IT for Masses </td>
            <td>Kohima, Chuchumliyang</td>
        </tr><tr>
            <td>7</td>
            <td>Tripura</td>
            <td>1</td>
            <td>Agartala</td>
        </tr><tr>
            <td>8</td>
            <td>Sikkim</td>
            <td>1</td>
            <td>Gangtok </td>
        </tr>
        <tr>
            <td></td>
            <td><span style="font-weight:600">Total</span></td>
            <td><span style="font-weight:600">24</span></td>
            <td></td>
        </tr>

    </table>
<br>
           <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Duration &amp; Total Cost of the Project</blockquote>
  
  <p>
      The total <span style="font-weight:600">project duration is 3 years (36 months)</span>.
The total <span style="font-weight:600">budget outlay of the project is Rs. 38.96 crores</span> (Rupees Thirty eight crores, ninety six lakhs, eighty two thousand two hundred and fifty sixty only) payable over a period of 3 years for the <span style="font-weight:600">training of 50,000 state govt employees.</span>
  </p> 
<br>
         <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Project Structure</blockquote>
  <ul>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  The main stakeholders of the project are :<br>
   <img src="assets/dist/img/projectstructure.png" height="400" alt="project Structure"/>
    </li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  A Project PMU comprising of 7 members (Project Coordinator-1, Assistant Coordinators-2, Technical Assistants-3, & Multitasking Staff-1) will be set up at NIELIT HQs which will be responsible for on ground coordination, implementation, periodic reports, MIS, invoicing and receivables.</li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  The centre directors of NIELIT centres in each state will be responsible for coordinating with various departments, mobilisation of trainees, training classes, trainers and finally certification of successful candidates.</li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  The state will depute a nodal officer to coordinate with each district and state department to mobilise requisite trainees.</li>

   
   </ul>
  


                                                <br><br> </div>
                                            <div id="course" class="tab-pane fade">
                                                <br>

                                             <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Programme Offered</blockquote>
 
<table class="table table-striped table-bordered table-hover">
    <thead>
        <th>S. No.</th>
        <th>Training Module</th>
        <th>Duration(in hours)</th>
    </thead>
    <tbody>
        <tr>
            <td>1.</td>
            <td>Course on Computer Concepts (CCC) with Financial Services</td>
            <td>80</td>
            

        </tr>
         <tr>
            <td>2.</td>
            <td>e-Governance Services</td>
            <td>06</td>
            

        </tr>
         <tr>
            <td>3.</td>
            <td>Digital Payment</td>
            <td>06</td>
            

        </tr>
         <tr>
            <td>4.</td>
            <td>GST Skilling</td>
            <td>06</td>
            

        </tr>
         <tr>
            <td>5.</td>
            <td>Customised Soft Skills Training</td>
            <td>02</td>
            

        </tr>
        <tr>
            <td></td>
            <td>Total</td>
            <td>100</td>
        </tr>

    </tbody>


</table>


                                                <br>

                                             <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Detailed Course Structure</blockquote>
 

<h4><span style="font-weight:600"> (A) Course on Computer Concepts (CCC) – 80 hours </span></h4>
<h4><span style="font-weight:600"> Course Structure </span></h4>

<p>The course is designed to equip a person to use computers for professional as well as day to day use. It provides theoretical background as well as in depth knowledge of Software/ packages. After completing the course the incumbent will be digitally literate and will be able to:</p><br>

<ul>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Acquire confidence in using computer techniques available to users;</li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Recognise the basic components of computers and terminology;</li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Understand data, information and file management;</li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Create documents using Word processor, Spread sheet &
Presentation Software;</li>
    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Understand computer networks, and browse the internet, content
search, email and collaborate with peers;</li>
<li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Use e-governance applications; and use computer to improve
existing skills and learn new skills</li>
<li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Use internet for digital financial services</li>
</ul>
<br>
<p>The module on financial literacy will enable the individuals to understand the various financial services and be aware of the various schemes of Government of India.</p>
    <br>
          <h4><span style="font-weight:600"> Course Content: </span></h4>
               
               <table class="table table-hover table-striped table-bordered">
        <tr>
            <th>S. No</th>
            <th>Chapter</th>
            <th>Theory Hours</th>
            <th>Tutorial Hours</th>
            <th>Practical Hours</th>
        </tr>
        <tr>
            <td>1.</td>
            <td>Introduction to computer</td>
            <td>2</td>
            <td>1</td>
            <td>4</td>
        </tr>
         <tr>
            <td>2.</td>
            <td>Introduction to GUI Based Operating System</td>
            <td>3</td>
            <td>-</td>
            <td>8</td>
        </tr>
         <tr>
            <td>3.</td>
            <td>Elements of Word Processing</td>
            <td>3.5</td>
            <td>2</td>
            <td>9</td>
        </tr>
         <tr>
            <td>4.</td>
            <td>Spreadsheets</td>
            <td>3.5</td>
            <td>2</td>
            <td>10</td>
        </tr>
         <tr>
            <td>5.</td>
            <td>Introduction to Internet, WWW and web browsers</td>
            <td>6</td>
            <td>-</td>
            <td>8</td>
        </tr>
         <tr>
            <td>6.</td>
            <td>Communication and Collaboration</td>
            <td>2</td>
            <td>-</td>
            <td>2</td>
        </tr>
         <tr>
            <td>7.</td>
            <td>Application of presentations</td>
            <td>4</td>
            <td>-</td>
            <td>8</td>
        </tr>
         <tr>
            <td>8.</td>
            <td>Application of Digital Financial Services</td>
            <td>1</td>
            <td>-</td>
            <td>1</td>
        </tr>
         <tr>
            <td></td>
            <td><span style="font-weight:600">Total Hours</span></td>
            <td><span style="font-weight:600">25</span></td>
            <td><span style="font-weight:600">5</span></td>
            <td><span style="font-weight:600">50</span></td>
        </tr>
         </table>

         <br>
        
          <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">(B) Curriculum for Digital Payment and e-Gov Citizen Centric Services</blockquote>
               
               <table class="table table-striped ">
        <tr>
            <th style="min-width: 50px">S. No</th>
            <th>Chapter</th>
            
            <th style="width="25%;"> Hours</th>
        </tr>
        <tr>
            <td>1  </td>
            <td><p>As the thrust of the Government is on promoting cashless transactions through mobile phones, the course content would have emphasis on to carry out cashless transactions using digital financial tools:</p>
                <ul>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> USSD </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> UPI </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> eWallet </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> AEPS </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Card </li>
                     <li><i class="hvr-buzz-out fa fa-arrow-right"></i> POS </li>
                </ul></td>
            <td rowspan="2" style="vertical-align: middle">12</td>
        </tr>
        <tr>
            <td>2  </td>
            <td><p>e-Gov Citizen Centric Services</p>
             <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> G2C Services – Caste Certificate, Domicile Certificate, Income Certificate </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Banking Services </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> IRCTC – Railway reservation </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Insurance </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Telephone/ Data card recharge </li>
                     <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Election ID Printing </li>
                     <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Electricity – bill payment </li>
                     <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Pan Card </li>
                     <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Passport </li>

                </ul>
            </td>
            
        </tr>
    </table>
    
<br>


    
              <blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">(C) Capsule Course on GST</blockquote>
       <table class="table table-striped ">
        <tr>
            <th style="min-width: 50px">S. No</th>
            <th>Chapter</th>
            
            <th style="width="25%;"> Hours</th>
        </tr>

       <tr>
           <td><br>1.</td>
           <td>
            <br>
            <h4><span style="font-weight:600"> SECTION-I (Basic Digital Literacy and Financial Inclusion)</span></h4>
            <h4><span style="font-weight:600"> Introduction to Computers</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Concept of computing, data and information</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Applications of IECT : e-Governance, e-Commerce </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Bringing computing to life </li>
             </ul>               

<h4><span style="font-weight:600"> Introduction to Internet</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Communication on Internet</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>Internet Accessing , Browsing, </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Search Engines : Search for content </li>
             </ul>

             <h4><span style="font-weight:600"> Cashless Transactions</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Benefits of Digital Payments</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> 
                    Modes and Utilities of Digital Payments: Internet
Banking, Unified Payment Interface (UPI), Unstructured Supplementary Service Data (USSD), BHIM App, Bharat QR, Aadhar Enabled Payment System (AEPS) , Bharat Bill Payment Systems (BBPS)
                </li>
                    
             </ul>

           </td>
           <td>02</td>
       </tr>
           <tr>
           <td><br>2.</td>
           <td>
               <br>
 <h4><span style="font-weight:600"> SECTION-II (GST Guide and Know-Hows)</span></h4>
            <h4><span style="font-weight:600"> (A) Introduction to GST</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> About New GST Regime</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> What is SGST, CGST &amp; IGST </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> How will input tax credits be adjusted between states and centre </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Time ,Place and Value of Supply </li>
                    
             </ul>               

<h4><span style="font-weight:600"> GST Registration</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Procedure of Registration &amp; Migration of existing Tax Payer</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>Procedure of Registration of new joinee </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Transition to GST </li>
             </ul>

             <h4><span style="font-weight:600"> Know Hows of GST Portal</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Log-in: Registration &amp; other details</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Personalization
                </li>
                <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Uploading the credentials &amp; other details regarding
business
                </li>
                    
             </ul>
 <h4><span style="font-weight:600"> Know Hows of GST Portal</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> GST Returns </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"> Penalties &mp; Appeals</i> 
                </li>
                <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Composition Scheme
                </li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Payments &amp; Refunds
                </li>
                <li><i class="hvr-buzz-out fa fa-arrow-right"></i> Accounts &amp; Records
                </li>
             </ul>


           </td>
           <td>04 </td>
       </tr>

<tr>
    <td><br>3.</td>
    <td>
        <br>
<h4><span style="font-weight:600"> SECTION-III (Securing Digital &amp; Online Transactions)</span></h4>
<h4><span style="font-weight:600">(A) Cyber Safety</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Importance of Cyber Safety &amp; Security</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Threats -Torrent and Infected Websites, Unsecured Wi-Fi</li>
               
             </ul>

<h4><span style="font-weight:600">(B) Using Internet Safely:</span></h4>
              <ul>

                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Email Usage Best Practices, Spam Filter, Safe Downloading</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Online Banking &amp; Shopping</li>
                    <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  </li>
               <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Securing Web Browser</li>
               <li><i class="hvr-buzz-out fa fa-arrow-right"></i>  Securing Wi-Fi and Bluetooth</li>
               
             </ul>


    </td>
    <td>01 </td>
</tr>

        </table>

<br>
<blockquote class="block-summery hidden-xs hidden-sm" style="
    background-image: url(assets/dist/img/fabric.png);background: rgba(97, 197, 153, 0.58);color: #000;text-align:center;">Section D</blockquote>
<table class="table">
   <tr>
       <td>1. </td>
       <td>Customised Soft Skills Training</td>
       <td>02 </td>
   </tr> 
</table>
                               
                               
    
                                                    <br><br> </div>

                                            <!--
                                            <div id="cost" class="tab-pane fade">
                                             
                                            <br><br></div>
-->

                                            <div id="target" class="tab-pane fade">
                                                <br>
                                             <table class="table table-bordered table-striped table-hove" >
                                                
                                                
                                                 <tbody>
                                                    <tr style="border-top:1px #ddd">
                                                     <td colspan="8" style="text-align: center;font-weight: 600;font-size: 16px;">Total Target: 50000</td>
                                                     
                                                     </tr>
                                                
                                                     <tr>
                                                         <td class="fontsix">Sr. No.</td>
                                                         <td class="fontsix">State</td>
                                                         <td class="fontsix">No. of Districts</td>
                                                         <td class="fontsix">Target</td>
                                                         <td class="fontsix">Year 1</td>
                                                         <td class="fontsix">Year 2</td>
                                                         <td class="fontsix">Year 3</td>
                                                         <td class="fontsix">Total</td>

                                                     </tr>
                                                     <tr>
                                                         <td>1.</td>
                                                         <td>Arunachal Pradesh</td>
                                                         <td>20</td>
                                                         <td class="fontsix">1517</td>
                                                         <td class="fontsix">303</td>
                                                         <td class="fontsix">607</td>
                                                         <td class="fontsix">607</td>
                                                         <td class="fontsix">1517</td>

                                                     </tr>
                                                      <tr>
                                                         <td>2.</td>
                                                         <td>Assam</td>
                                                         <td>33</td>
                                                         <td class="fontsix">34185</td>
                                                         <td class="fontsix">6837</td>
                                                         <td class="fontsix">13674</td>
                                                         <td class="fontsix">13674</td>
                                                         <td class="fontsix">34185</td>
                                                         
                                                     </tr>
                                                      <tr>
                                                         <td>3.</td>
                                                         <td>Manipur</td>
                                                         <td>16</td>
                                                         <td class="fontsix">2985</td>
                                                         <td class="fontsix">597</td>
                                                         <td class="fontsix">1194</td>
                                                         <td class="fontsix">1194</td>
                                                         <td class="fontsix">2985</td>
                                                         
                                                     </tr>
                                                      <tr>
                                                         <td>4.</td>
                                                         <td>Meghalaya</td>
                                                         <td>11</td>
                                                         <td class="fontsix">3250</td>
                                                         <td class="fontsix">650</td>
                                                         <td class="fontsix">1300</td>
                                                         <td class="fontsix">1300</td>
                                                         <td class="fontsix">3250</td>
                                                         
                                                     </tr>
                                                      <tr>
                                                         <td>5.</td>
                                                         <td>Mizoram</td>
                                                         <td>8</td>
                                                         <td class="fontsix">1197</td>
                                                         <td class="fontsix">239</td>
                                                         <td class="fontsix">479</td>
                                                         <td class="fontsix">479</td>
                                                         <td class="fontsix">1197</td>
                                                         
                                                     </tr>
                                                      <tr>
                                                         <td>6.</td>
                                                         <td>Nagaland</td>
                                                         <td>11</td>
                                                         <td class="fontsix">2172</td>
                                                         <td class="fontsix">434</td>
                                                         <td class="fontsix">869</td>
                                                         <td class="fontsix">869</td>
                                                         <td class="fontsix">2172</td>
                                                         
                                                     </tr>
                                                      <tr>
                                                         <td>7.</td>
                                                         <td>Sikkim</td>
                                                         <td>4</td>
                                                         <td class="fontsix">667</td>
                                                         <td class="fontsix">133</td>
                                                         <td class="fontsix">267</td>
                                                         <td class="fontsix">267</td>
                                                         <td class="fontsix">667</td>
                                                         
                                                     </tr>
                                                      <tr>
                                                         <td>8.</td>
                                                         <td>Tripura</td>
                                                         <td>8</td>
                                                         <td class="fontsix">4027</td>
                                                         <td class="fontsix">807</td>
                                                         <td class="fontsix">1610</td>
                                                         <td class="fontsix">1610</td>
                                                         <td class="fontsix">4027</td>
                                                         
                                                     </tr>

                                                     <tr>
                                                         <td></td>
                                                         <td></td>
                                                         <td class="fontsix">111</td>
                                                         <td class="fontsix">50000</td>
                                                         <td class="fontsix">10000</td>
                                                         <td class="fontsix">20000</td>
                                                         <td class="fontsix">20000</td>
                                                         <td class="fontsix">50000</td>
                                                     </tr>


                                                 </tbody>

                                             </table>
                                            <br><br></div>
<!--
<div id="document" class="tab-pane fade">



                                             
                                            <br><br></div>-->


                                        </div>
                                    </div>
                                </div>
                            </div><!--changing purpose-->


                           



                                       
                                        </div>
                                    </div>
                                </div>
                            </div>


                          
                            <!-- ./Messages -->
                        </div>
                        <!-- ./row -->
                    </div>
                   


                    <!-- ./cotainer -->
                </div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->
        <!-- Preloader -->
        <div id="preloader">
            <div class="preloader-position">
                <div class="preloader-wrapper big active">
                    <div class="spinner-layer spinner-teal">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Core Plugins
             =====================================================================-->
        <!-- jQuery -->
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- materialize  -->
        <script src="assets/plugins/materialize/js/materialize.min.js" type="text/javascript"></script>
        <!-- metismenu-master -->
        <script src="assets/plugins/metismenu-master/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- SlimScroll -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- m-custom-scrollbar -->
        <script src="assets/plugins/malihu-custom-scrollbar/jquery.mCustomScrollbar.concat.min.js" type="text/javascript"></script>
        <!-- scroll -->
        <script src="assets/plugins/simplebar/dist/simplebar.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins
             =====================================================================-->
        <!-- Start Page Lavel Plugins
             =====================================================================-->
        <!-- Sparkline js -->
        <script src="assets/plugins/sparkline/sparkline.min.js" type="text/javascript"></script>
        <!-- Counter js -->
        <script src="assets/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        <!-- ChartJs JavaScript -->
        <script src="assets/plugins/chartJs/Chart.min.js" type="text/javascript"></script>
        <!-- Monthly js -->
        <script src="assets/plugins/monthly/monthly.js" type="text/javascript"></script>

        <!-- End Page Lavel Plugins
             =====================================================================-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js-->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
       
 <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- custom js -->
        <script src="assets/dist/js/custom.js" type="text/javascript"></script>
        <!-- End Core Plugins-->
        <!-- Start Theme label Script
             =====================================================================-->
        <!-- main js -->
        <script src="assets/dist/js/main.js" type="text/javascript"></script>
        <!-- End Theme label Script
             =====================================================================-->
        <script>
             "use strict";
            $(document).ready(function () {
                function dtable() {
                    $('#dataTableExample1').DataTable({
                        "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                        "lengthMenu": [
                            [6, 25, 50, -1],
                            [6, 25, 50, "All"]
                        ],
                        "iDisplayLength": 25
                    });
                }
                return (dtable());
            });
        </script>
    



<!--

        <script>

            $(document).ready(function () {
                "use strict";
                // Message
                function slscroll() {
                    $('.chat_list , .activity-list , .message_inner').slimScroll({
                        size: '3px',
                        height: '320px',
                        allowPageScroll: true,
                        railVisible: true
                    });
                }
                slscroll();
                function chatscroll() {
                    $('.chat_list').slimScroll({
                        size: '3px',
                        height: '290px'
                    });
                }
                chatscroll();

                //monthly calender
                $('#m_calendar').monthly({
                    mode: 'event',
                    //jsonUrl: 'events.json',
                    //dataType: 'json'
                    xmlUrl: 'events.xml'
                });

                //panel refresh
                $.fn.refreshMe = function (opts) {
                    var $this = this,
                            defaults = {
                                ms: 1500,
                                started: function () {},
                                completed: function () {}
                            },
                            settings = $.extend(defaults, opts);

                    var panelToRefresh = $this.parents('.panel').find('.refresh-container');
                    var dataToRefresh = $this.parents('.panel').find('.refresh-data');
                    var ms = settings.ms;
                    var started = settings.started;		//function before timeout
                    var completed = settings.completed;	//function after timeout

                    $this.click(function () {
                        $this.addClass("fa-spin");
                        panelToRefresh.show();
                        started(dataToRefresh);
                        setTimeout(function () {
                            completed(dataToRefresh);
                            panelToRefresh.fadeOut(800);
                            $this.removeClass("fa-spin");
                        }, ms);
                        return false;
                    });
                };

                $(document).ready(function () {
                    $('.refresh, .refresh2').refreshMe({
                        started: function (ele) {
                            ele.html("Getting new data..");
                        },
                        completed: function (ele) {
                            ele.html("This is the new data after refresh..");
                        }
                    });
                });

                //line chart
                var ctx = document.getElementById("lineChart");
                var myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        datasets: [{
                                label: "Total income",
                                borderColor: "#73879C",
                                borderWidth: "1",
                                backgroundColor: "#73879C",
                                data: [22, 44, 67, 43, 76, 45, 12, 45, 65, 55, 42, 61, 73]
                            }, {
                                label: "Total Expense",
                                borderColor: "rgba(26, 187, 156, 0.64)",
                                borderWidth: "1",
                                backgroundColor: "rgba(26, 187, 156, 0.64)",
                                pointHighlightStroke: "rgba(26, 187, 156, 0.64)",
                                data: [16, 32, 18, 26, 42, 33, 44, 24, 19, 16, 67, 71, 65]
                            }]
                    },
                    options: {
                        responsive: true,
                        tooltips: {
                            mode: 'index',
                            intersect: false
                        },
                        hover: {
                            mode: 'nearest',
                            intersect: true
                        }

                    }
                });

            });
        </script>

 
 <script src="./dash-home.jsp_files/highcharts.js.download"></script>
<script src="./dash-home.jsp_files/exporting.js.download"></script>
<script src="./dash-home.jsp_files/drilldown.js.download"></script>
<script src="https://code.highcharts.com/modules/heatmap.js"></script>
<script src="https://code.highcharts.com/modules/treemap.js"></script>
-->

    </body>

</html>
