-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2020 at 05:26 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ewaste_gangtok`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Auid` varchar(20) NOT NULL,
  `Apwd` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Auid`, `Apwd`) VALUES
('admin', 'manager');

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `app_id` int(11) NOT NULL,
  `e_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `std_reg_id` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`app_id`, `e_id`, `job_id`, `std_reg_id`) VALUES
(3, 1, 3, '1'),
(4, 3, 4, '1'),
(5, 6, 6, 'bicky'),
(6, 2, 4, 'madhav'),
(7, 7, 5, 'madhav');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `cmp_id` varchar(10) NOT NULL,
  `cmp_pwd` varchar(15) NOT NULL,
  `cmp_name` varchar(30) NOT NULL,
  `cont_person` varchar(35) NOT NULL,
  `cmp_mail_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`cmp_id`, `cmp_pwd`, `cmp_name`, `cont_person`, `cmp_mail_id`) VALUES
('info', 'info', 'Infosys Ltd', 'Mr.Arvind Rajgopal', 'info@infosys.com'),
('tcs', 'tcs', 'TCS', 'Keshung Sherpa', 'ks@yahoo.com'),
('wipro', 'wipro', 'Wipro', 'Biky Chowhan', 'biky@hiotmail.com'),
('zen', 'zen', 'Zenith Infotech', 'Mr. Akash Chaudhuri', 'akash1@zenith.com');

-- --------------------------------------------------------

--
-- Table structure for table `d_reg`
--

CREATE TABLE `d_reg` (
  `user_id` varchar(20) NOT NULL,
  `pwd1` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `d_reg`
--

INSERT INTO `d_reg` (`user_id`, `pwd1`) VALUES
('1', 'ray'),
('123', '123'),
('201316', '123'),
('456', ''),
('bicky', '123'),
('madhav', '123');

-- --------------------------------------------------------

--
-- Table structure for table `eligibility`
--

CREATE TABLE `eligibility` (
  `e_id` int(10) NOT NULL,
  `yop` int(10) NOT NULL,
  `job_id` int(10) NOT NULL,
  `strm_id` int(10) NOT NULL,
  `cmp_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eligibility`
--

INSERT INTO `eligibility` (`e_id`, `yop`, `job_id`, `strm_id`, `cmp_id`) VALUES
(1, 2018, 3, 1, 'wipro'),
(2, 2018, 3, 2, 'wipro'),
(3, 2018, 4, 1, 'info'),
(4, 2018, 4, 2, 'info'),
(5, 2018, 5, 2, 'tcs'),
(6, 2018, 6, 1, 'info'),
(7, 2018, 7, 2, 'zen');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` int(10) NOT NULL,
  `job_name` varchar(15) NOT NULL,
  `cmp_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `job_name`, `cmp_id`) VALUES
(3, 'Php Developer', 'wipro'),
(4, 'Technical', 'info'),
(5, 'Php Developer', 'tcs'),
(6, 'Java Developer', 'info'),
(7, 'Python Programm', 'zen');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `marks_id` int(11) NOT NULL,
  `std_reg_id` varchar(10) NOT NULL,
  `app_id` int(11) NOT NULL,
  `apt_marks` int(11) NOT NULL,
  `tech_marks` int(3) NOT NULL,
  `hr_marks` int(3) NOT NULL,
  `total` int(3) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`marks_id`, `std_reg_id`, `app_id`, `apt_marks`, `tech_marks`, `hr_marks`, `total`, `status`) VALUES
(1, '1', 3, 77, 77, 77, 231, 'Selected'),
(2, '1', 4, 75, 75, 74, 224, 'Selected'),
(3, 'bicky', 6, 78, 60, 60, 198, '');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `std_reg_id` varchar(10) NOT NULL,
  `strm_id` int(10) NOT NULL,
  `std_name` varchar(15) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `add` varchar(30) NOT NULL,
  `city` varchar(15) NOT NULL,
  `pin` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`std_reg_id`, `strm_id`, `std_name`, `email_id`, `add`, `city`, `pin`) VALUES
('1', 1, 'Ashis Ray', 'ashis@gmail.com', 'Park Circus', 'Kolkata', 700017),
('201316', 1, 'bijay', 'bijay@gmail.com', 'skm', 'ranipol', 737102),
('bicky', 1, 'Bicky Chohan', 'bc@gmail.com', 'Hakimpara', 'Siliguri', 734005),
('jharna', 2, 'Jharna Bose', ' df@aboltabol.com', 'Gandhi Road', 'Durgapur', 788778),
('madhav', 2, 'Madhav Ghosh', 'gfhf@gmail.com', 'Behala', 'Kolkata', 700034);

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `note_id` int(10) NOT NULL,
  `details` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`note_id`, `details`) VALUES
(1, ''),
(2, ''),
(3, ''),
(4, ''),
(5, ''),
(6, ''),
(7, ''),
(8, ''),
(9, ''),
(10, ''),
(11, ''),
(12, ''),
(13, ''),
(14, ''),
(15, ''),
(16, ''),
(17, ''),
(18, ''),
(19, ''),
(20, ''),
(21, 'All students of final year are requested to register their name in Placement cell.');

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `Record_id` int(11) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `cmp_name` varchar(30) NOT NULL,
  `strm_name` varchar(30) NOT NULL,
  `job_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`Record_id`, `student_name`, `cmp_name`, `strm_name`, `job_name`) VALUES
(1, 'Vicky Chohan', 'TCS', 'MCA', 'TECHNICAL '),
(2, 'Keshung Sherpa', 'Wipro', 'MCA', 'DEVELOPER'),
(3, 'Romanka Subba', 'infosys', 'MCA', 'ASST TEACHER'),
(4, 'Pema Sonam Bhutia', 'HP', 'MCA', 'SALES EXCUITIVE'),
(5, 'Mohan Chettri', 'CU', 'BCA', 'ASST. TECH'),
(6, 'Dinesh Adhikari', 'SU', 'BCA', 'ASST DEVEP'),
(7, 'M.K.Ghose', 'SMU', 'BCA', 'ASST PROF'),
(8, 'Mohan Pradhan', 'SMIT', 'BCA', 'ASST TEACHER');

-- --------------------------------------------------------

--
-- Table structure for table `stream`
--

CREATE TABLE `stream` (
  `strm_id` int(10) NOT NULL,
  `strm_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stream`
--

INSERT INTO `stream` (`strm_id`, `strm_name`) VALUES
(1, 'MCA'),
(2, 'BCA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Auid`);

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`cmp_id`);

--
-- Indexes for table `d_reg`
--
ALTER TABLE `d_reg`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `eligibility`
--
ALTER TABLE `eligibility`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`marks_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`std_reg_id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`Record_id`);

--
-- Indexes for table `stream`
--
ALTER TABLE `stream`
  ADD PRIMARY KEY (`strm_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `eligibility`
--
ALTER TABLE `eligibility`
  MODIFY `e_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `job_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `marks_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `note_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `Record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
